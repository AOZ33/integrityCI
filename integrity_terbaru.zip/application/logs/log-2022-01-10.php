<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

DEBUG - 2022-01-10 03:59:49 --> UTF-8 Support Enabled
DEBUG - 2022-01-10 03:59:49 --> No URI present. Default controller set.
DEBUG - 2022-01-10 03:59:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-10 03:59:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-10 03:59:49 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-10 03:59:49 --> Total execution time: 0.0302
DEBUG - 2022-01-10 10:56:12 --> UTF-8 Support Enabled
DEBUG - 2022-01-10 10:56:12 --> No URI present. Default controller set.
DEBUG - 2022-01-10 10:56:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-10 10:56:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-10 10:56:12 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-10 10:56:12 --> Total execution time: 0.0308
DEBUG - 2022-01-10 10:56:12 --> UTF-8 Support Enabled
DEBUG - 2022-01-10 10:56:12 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-01-10 10:56:12 --> 404 Page Not Found: Assets/https:
DEBUG - 2022-01-10 10:56:19 --> UTF-8 Support Enabled
DEBUG - 2022-01-10 10:56:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-10 10:56:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-10 10:56:19 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-10 10:56:19 --> UTF-8 Support Enabled
DEBUG - 2022-01-10 10:56:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-10 10:56:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-10 10:56:19 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-10 10:56:19 --> Total execution time: 0.0028
DEBUG - 2022-01-10 10:56:19 --> UTF-8 Support Enabled
DEBUG - 2022-01-10 10:56:19 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-01-10 10:56:19 --> 404 Page Not Found: Assets/https:
DEBUG - 2022-01-10 10:56:27 --> UTF-8 Support Enabled
DEBUG - 2022-01-10 10:56:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-10 10:56:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-10 10:56:27 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-10 10:56:27 --> UTF-8 Support Enabled
DEBUG - 2022-01-10 10:56:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-10 10:56:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-10 10:56:27 --> Total execution time: 0.0056
DEBUG - 2022-01-10 10:56:37 --> UTF-8 Support Enabled
DEBUG - 2022-01-10 10:56:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-10 10:56:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-10 10:56:37 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-10 10:56:37 --> Total execution time: 0.1502
DEBUG - 2022-01-10 10:59:15 --> UTF-8 Support Enabled
DEBUG - 2022-01-10 10:59:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-10 10:59:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-10 10:59:15 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-10 10:59:15 --> Total execution time: 0.0328
DEBUG - 2022-01-10 10:59:15 --> UTF-8 Support Enabled
DEBUG - 2022-01-10 10:59:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-10 10:59:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-10 10:59:15 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-10 10:59:15 --> Total execution time: 0.0038
DEBUG - 2022-01-10 11:06:53 --> UTF-8 Support Enabled
DEBUG - 2022-01-10 11:06:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-10 11:06:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-10 11:06:53 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-10 11:06:53 --> UTF-8 Support Enabled
DEBUG - 2022-01-10 11:06:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-10 11:06:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-10 11:06:53 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-10 11:06:53 --> Total execution time: 0.0061
DEBUG - 2022-01-10 11:11:55 --> UTF-8 Support Enabled
DEBUG - 2022-01-10 11:11:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-10 11:11:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-10 11:11:55 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-10 11:11:55 --> UTF-8 Support Enabled
DEBUG - 2022-01-10 11:11:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-10 11:11:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-10 11:11:55 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-10 11:11:55 --> Total execution time: 0.0055
DEBUG - 2022-01-10 11:15:23 --> UTF-8 Support Enabled
DEBUG - 2022-01-10 11:15:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-10 11:15:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-10 11:15:23 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-10 11:15:23 --> UTF-8 Support Enabled
DEBUG - 2022-01-10 11:15:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-10 11:15:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-10 11:15:23 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-10 11:15:23 --> Total execution time: 0.0060
DEBUG - 2022-01-10 11:19:13 --> UTF-8 Support Enabled
DEBUG - 2022-01-10 11:19:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-10 11:19:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-10 11:19:13 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-10 11:19:13 --> UTF-8 Support Enabled
DEBUG - 2022-01-10 11:19:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-10 11:19:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-10 11:19:13 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-10 11:19:13 --> Total execution time: 0.0060
DEBUG - 2022-01-10 11:22:02 --> UTF-8 Support Enabled
DEBUG - 2022-01-10 11:22:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-10 11:22:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-10 11:22:02 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-10 11:22:02 --> UTF-8 Support Enabled
DEBUG - 2022-01-10 11:22:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-10 11:22:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-10 11:22:02 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-10 11:22:02 --> Total execution time: 0.0047
DEBUG - 2022-01-10 11:35:20 --> UTF-8 Support Enabled
DEBUG - 2022-01-10 11:35:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-10 11:35:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-10 11:35:20 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-10 11:35:20 --> UTF-8 Support Enabled
DEBUG - 2022-01-10 11:35:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-10 11:35:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-10 11:35:20 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-10 11:35:20 --> Total execution time: 0.0067
DEBUG - 2022-01-10 11:41:06 --> UTF-8 Support Enabled
DEBUG - 2022-01-10 11:41:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-10 11:41:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-10 11:41:06 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-10 11:41:07 --> UTF-8 Support Enabled
DEBUG - 2022-01-10 11:41:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-10 11:41:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-10 11:41:07 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-10 11:41:07 --> Total execution time: 0.0063
DEBUG - 2022-01-10 11:46:29 --> UTF-8 Support Enabled
DEBUG - 2022-01-10 11:46:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-10 11:46:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-10 11:46:29 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-10 11:46:29 --> UTF-8 Support Enabled
DEBUG - 2022-01-10 11:46:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-10 11:46:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-10 11:46:29 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-10 11:46:29 --> Total execution time: 0.0066
DEBUG - 2022-01-10 11:49:54 --> UTF-8 Support Enabled
DEBUG - 2022-01-10 11:49:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-10 11:49:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-10 11:49:54 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-10 11:49:54 --> UTF-8 Support Enabled
DEBUG - 2022-01-10 11:49:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-10 11:49:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-10 11:49:54 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-10 11:49:54 --> Total execution time: 0.0055
DEBUG - 2022-01-10 11:53:16 --> UTF-8 Support Enabled
DEBUG - 2022-01-10 11:53:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-10 11:53:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-10 11:53:17 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-10 11:53:17 --> UTF-8 Support Enabled
DEBUG - 2022-01-10 11:53:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-10 11:53:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-10 11:53:17 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-10 11:53:17 --> Total execution time: 0.0060
DEBUG - 2022-01-10 11:56:33 --> UTF-8 Support Enabled
DEBUG - 2022-01-10 11:56:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-10 11:56:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-10 11:56:33 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-10 11:56:33 --> UTF-8 Support Enabled
DEBUG - 2022-01-10 11:56:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-10 11:56:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-10 11:56:33 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-10 11:56:33 --> Total execution time: 0.0064
DEBUG - 2022-01-10 11:57:34 --> UTF-8 Support Enabled
DEBUG - 2022-01-10 11:57:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-10 11:57:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-10 11:57:34 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-10 11:57:35 --> Total execution time: 0.1161
DEBUG - 2022-01-10 12:57:17 --> UTF-8 Support Enabled
DEBUG - 2022-01-10 12:57:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-10 12:57:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-10 12:57:17 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-10 12:57:17 --> Total execution time: 0.0340
DEBUG - 2022-01-10 13:00:02 --> UTF-8 Support Enabled
DEBUG - 2022-01-10 13:00:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-10 13:00:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-10 13:00:02 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-10 13:00:02 --> UTF-8 Support Enabled
DEBUG - 2022-01-10 13:00:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-10 13:00:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-10 13:00:02 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-10 13:00:02 --> Total execution time: 0.0050
DEBUG - 2022-01-10 13:04:24 --> UTF-8 Support Enabled
DEBUG - 2022-01-10 13:04:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-10 13:04:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-10 13:04:24 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-10 13:04:24 --> UTF-8 Support Enabled
DEBUG - 2022-01-10 13:04:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-10 13:04:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-10 13:04:24 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-10 13:04:24 --> Total execution time: 0.0064
DEBUG - 2022-01-10 13:10:37 --> UTF-8 Support Enabled
DEBUG - 2022-01-10 13:10:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-10 13:10:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-10 13:10:37 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-10 13:10:37 --> UTF-8 Support Enabled
DEBUG - 2022-01-10 13:10:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-10 13:10:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-10 13:10:37 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-10 13:10:37 --> Total execution time: 0.0072
DEBUG - 2022-01-10 13:12:40 --> UTF-8 Support Enabled
DEBUG - 2022-01-10 13:12:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-10 13:12:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-10 13:12:40 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-10 13:12:40 --> UTF-8 Support Enabled
DEBUG - 2022-01-10 13:12:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-10 13:12:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-10 13:12:40 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-10 13:12:40 --> Total execution time: 0.0048
DEBUG - 2022-01-10 13:40:03 --> UTF-8 Support Enabled
DEBUG - 2022-01-10 13:40:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-10 13:40:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-10 13:40:03 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-10 13:40:03 --> UTF-8 Support Enabled
DEBUG - 2022-01-10 13:40:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-10 13:40:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-10 13:40:03 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-10 13:40:03 --> Total execution time: 0.0078
DEBUG - 2022-01-10 13:50:03 --> UTF-8 Support Enabled
DEBUG - 2022-01-10 13:50:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-10 13:50:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-10 13:50:03 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-10 13:50:03 --> UTF-8 Support Enabled
DEBUG - 2022-01-10 13:50:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-10 13:50:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-10 13:50:03 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-10 13:50:03 --> Total execution time: 0.0068
DEBUG - 2022-01-10 13:54:23 --> UTF-8 Support Enabled
DEBUG - 2022-01-10 13:54:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-10 13:54:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-10 13:54:23 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-10 13:54:23 --> UTF-8 Support Enabled
DEBUG - 2022-01-10 13:54:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-10 13:54:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-10 13:54:23 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-10 13:54:23 --> Total execution time: 0.0058
DEBUG - 2022-01-10 14:01:24 --> UTF-8 Support Enabled
DEBUG - 2022-01-10 14:01:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-10 14:01:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-10 14:01:24 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-10 14:01:24 --> UTF-8 Support Enabled
DEBUG - 2022-01-10 14:01:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-10 14:01:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-10 14:01:24 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-10 14:01:24 --> Total execution time: 0.0070
DEBUG - 2022-01-10 14:13:12 --> UTF-8 Support Enabled
DEBUG - 2022-01-10 14:13:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-10 14:13:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-10 14:13:12 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-10 14:13:13 --> UTF-8 Support Enabled
DEBUG - 2022-01-10 14:13:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-10 14:13:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-10 14:13:13 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-10 14:13:13 --> Total execution time: 0.0061
DEBUG - 2022-01-10 14:22:59 --> UTF-8 Support Enabled
DEBUG - 2022-01-10 14:22:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-10 14:22:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-10 14:22:59 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-10 14:22:59 --> UTF-8 Support Enabled
DEBUG - 2022-01-10 14:22:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-10 14:22:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-10 14:22:59 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-10 14:22:59 --> Total execution time: 0.0063
DEBUG - 2022-01-10 14:37:25 --> UTF-8 Support Enabled
DEBUG - 2022-01-10 14:37:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-10 14:37:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-10 14:37:25 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-10 14:37:25 --> UTF-8 Support Enabled
DEBUG - 2022-01-10 14:37:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-10 14:37:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-10 14:37:25 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-10 14:37:25 --> Total execution time: 0.0061
DEBUG - 2022-01-10 14:37:28 --> UTF-8 Support Enabled
DEBUG - 2022-01-10 14:37:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-10 14:37:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-10 14:37:28 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-10 14:37:28 --> Total execution time: 0.1127
DEBUG - 2022-01-10 14:39:23 --> UTF-8 Support Enabled
DEBUG - 2022-01-10 14:39:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-10 14:39:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-10 14:39:23 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-10 14:39:23 --> Total execution time: 0.0054
DEBUG - 2022-01-10 14:39:36 --> UTF-8 Support Enabled
DEBUG - 2022-01-10 14:39:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-10 14:39:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-10 14:39:36 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-10 14:39:36 --> Total execution time: 0.1088
DEBUG - 2022-01-10 14:39:39 --> UTF-8 Support Enabled
DEBUG - 2022-01-10 14:39:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-10 14:39:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-10 14:39:39 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-10 14:39:39 --> Total execution time: 0.0039
DEBUG - 2022-01-10 14:39:42 --> UTF-8 Support Enabled
DEBUG - 2022-01-10 14:39:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-10 14:39:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-10 14:39:42 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-10 14:39:42 --> Total execution time: 0.1491
DEBUG - 2022-01-10 14:55:58 --> UTF-8 Support Enabled
DEBUG - 2022-01-10 14:55:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-10 14:55:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-10 14:55:59 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-10 14:55:59 --> UTF-8 Support Enabled
DEBUG - 2022-01-10 14:55:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-10 14:55:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-10 14:55:59 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-10 14:55:59 --> Total execution time: 0.1152
DEBUG - 2022-01-10 14:56:46 --> UTF-8 Support Enabled
DEBUG - 2022-01-10 14:56:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-10 14:56:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-10 14:56:46 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-10 14:56:46 --> Total execution time: 0.0064
DEBUG - 2022-01-10 14:59:16 --> UTF-8 Support Enabled
DEBUG - 2022-01-10 14:59:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-10 14:59:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-10 14:59:16 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-10 14:59:16 --> UTF-8 Support Enabled
DEBUG - 2022-01-10 14:59:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-10 14:59:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-10 14:59:16 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-10 14:59:16 --> Total execution time: 0.0051
DEBUG - 2022-01-10 15:03:13 --> UTF-8 Support Enabled
DEBUG - 2022-01-10 15:03:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-10 15:03:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-10 15:03:13 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-10 15:03:13 --> UTF-8 Support Enabled
DEBUG - 2022-01-10 15:03:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-10 15:03:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-10 15:03:13 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-10 15:03:13 --> Total execution time: 0.0060
DEBUG - 2022-01-10 15:10:54 --> UTF-8 Support Enabled
DEBUG - 2022-01-10 15:10:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-10 15:10:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-10 15:10:54 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-10 15:10:54 --> UTF-8 Support Enabled
DEBUG - 2022-01-10 15:10:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-10 15:10:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-10 15:10:54 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-10 15:10:54 --> Total execution time: 0.0062
DEBUG - 2022-01-10 15:14:46 --> UTF-8 Support Enabled
DEBUG - 2022-01-10 15:14:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-10 15:14:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-10 15:14:46 --> Form_validation class already loaded. Second attempt ignored.
ERROR - 2022-01-10 15:14:46 --> Severity: Warning --> implode(): Invalid arguments passed /home/dunr4521/public_html/integrity/application/controllers/Appointment.php 28
ERROR - 2022-01-10 15:14:46 --> Query error: Column 'description' cannot be null - Invalid query: INSERT INTO `appointment` (`name`, `name_a`, `package`, `description`, `photo_g`, `box`, `ukuran_p`, `ukuran_w`, `tambahan`, `u20x30`, `u25x30`, `u30x30`, `video`, `lainnya`, `wedding_book`, `address`, `phone`, `email`, `instagram`, `price`, `dp`, `nilai`, `uang`, `date_l`, `w_lamaran`, `place_l`, `date_p`, `w_prewed`, `date_w`, `w_akad`, `w_resepsi`, `date_m`, `w_siram`, `place_m`, `date_s`, `w_live`, `place_s`, `date_a`, `n_acara`, `w_lain`, `place_p`, `place_w`, `place_a`, `date_dp`, `date_n`, `date_u`, `more`, `more_p`, `more_w`, `more_m`, `more_s`, `more_a`) VALUES ('Deasy & I Made Pramartha', '', 'Lamaran 2.75jt ', NULL, '', '', '', '', '', '', '', '', '', '', '', 'Jl. Batu Pualam dalam No.1 (Gunung Batu)', '081337110071', 'deasyariyantikd@yahoo.com', '@deasyakd', 'Rp. 2.750.000', 'Rp. 550.000', '', 'Rp. 2.200.000', '2021-01-14', '', 'Senusa Resto', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '2020-11-30', '', '', 'Sore', '', '', '', '', '')
DEBUG - 2022-01-10 15:14:46 --> UTF-8 Support Enabled
DEBUG - 2022-01-10 15:14:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-10 15:14:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-10 15:14:46 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-10 15:14:46 --> Total execution time: 0.0053
DEBUG - 2022-01-10 15:20:10 --> UTF-8 Support Enabled
DEBUG - 2022-01-10 15:20:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-10 15:20:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-10 15:20:10 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-10 15:20:10 --> UTF-8 Support Enabled
DEBUG - 2022-01-10 15:20:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-10 15:20:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-10 15:20:10 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-10 15:20:10 --> Total execution time: 0.0053
DEBUG - 2022-01-10 15:25:38 --> UTF-8 Support Enabled
DEBUG - 2022-01-10 15:25:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-10 15:25:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-10 15:25:38 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-10 15:25:38 --> UTF-8 Support Enabled
DEBUG - 2022-01-10 15:25:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-10 15:25:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-10 15:25:38 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-10 15:25:38 --> Total execution time: 0.0070
DEBUG - 2022-01-10 15:29:06 --> UTF-8 Support Enabled
DEBUG - 2022-01-10 15:29:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-10 15:29:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-10 15:29:06 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-10 15:29:06 --> UTF-8 Support Enabled
DEBUG - 2022-01-10 15:29:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-10 15:29:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-10 15:29:06 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-10 15:29:06 --> Total execution time: 0.0065
DEBUG - 2022-01-10 15:37:53 --> UTF-8 Support Enabled
DEBUG - 2022-01-10 15:37:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-10 15:37:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-10 15:37:53 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-10 15:37:53 --> UTF-8 Support Enabled
DEBUG - 2022-01-10 15:37:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-10 15:37:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-10 15:37:53 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-10 15:37:53 --> Total execution time: 0.0064
DEBUG - 2022-01-10 16:02:50 --> UTF-8 Support Enabled
DEBUG - 2022-01-10 16:02:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-10 16:02:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-10 16:02:50 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-10 16:02:50 --> UTF-8 Support Enabled
DEBUG - 2022-01-10 16:02:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-10 16:02:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-10 16:02:50 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-10 16:02:50 --> Total execution time: 0.0071
DEBUG - 2022-01-10 16:04:10 --> UTF-8 Support Enabled
DEBUG - 2022-01-10 16:04:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-10 16:04:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-10 16:04:10 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-10 16:04:10 --> UTF-8 Support Enabled
DEBUG - 2022-01-10 16:04:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-10 16:04:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-10 16:04:10 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-10 16:04:10 --> Total execution time: 0.0055
DEBUG - 2022-01-10 16:09:07 --> UTF-8 Support Enabled
DEBUG - 2022-01-10 16:09:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-10 16:09:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-10 16:09:07 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-10 16:09:07 --> UTF-8 Support Enabled
DEBUG - 2022-01-10 16:09:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-10 16:09:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-10 16:09:07 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-10 16:09:07 --> Total execution time: 0.0062
DEBUG - 2022-01-10 16:11:26 --> UTF-8 Support Enabled
DEBUG - 2022-01-10 16:11:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-10 16:11:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-10 16:11:26 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-10 16:11:26 --> UTF-8 Support Enabled
DEBUG - 2022-01-10 16:11:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-10 16:11:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-10 16:11:26 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-10 16:11:26 --> Total execution time: 0.0049
DEBUG - 2022-01-10 16:18:12 --> UTF-8 Support Enabled
DEBUG - 2022-01-10 16:18:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-10 16:18:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-10 16:18:12 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-10 16:18:12 --> UTF-8 Support Enabled
DEBUG - 2022-01-10 16:18:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-10 16:18:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-10 16:18:12 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-10 16:18:12 --> Total execution time: 0.0060
DEBUG - 2022-01-10 16:19:16 --> UTF-8 Support Enabled
DEBUG - 2022-01-10 16:19:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-10 16:19:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-10 16:19:16 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-10 16:19:16 --> UTF-8 Support Enabled
DEBUG - 2022-01-10 16:19:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-10 16:19:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-10 16:19:16 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-10 16:19:16 --> Total execution time: 0.0043
DEBUG - 2022-01-10 16:23:06 --> UTF-8 Support Enabled
DEBUG - 2022-01-10 16:23:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-10 16:23:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-10 16:23:06 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-10 16:23:06 --> UTF-8 Support Enabled
DEBUG - 2022-01-10 16:23:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-10 16:23:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-10 16:23:06 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-10 16:23:06 --> Total execution time: 0.0059
DEBUG - 2022-01-10 16:28:31 --> UTF-8 Support Enabled
DEBUG - 2022-01-10 16:28:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-10 16:28:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-10 16:28:31 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-10 16:28:31 --> UTF-8 Support Enabled
DEBUG - 2022-01-10 16:28:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-10 16:28:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-10 16:28:31 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-10 16:28:31 --> Total execution time: 0.0057
DEBUG - 2022-01-10 16:30:16 --> UTF-8 Support Enabled
DEBUG - 2022-01-10 16:30:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-10 16:30:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-10 16:30:16 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-10 16:30:16 --> UTF-8 Support Enabled
DEBUG - 2022-01-10 16:30:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-10 16:30:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-10 16:30:16 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-10 16:30:16 --> Total execution time: 0.0049
DEBUG - 2022-01-10 16:33:18 --> UTF-8 Support Enabled
DEBUG - 2022-01-10 16:33:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-10 16:33:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-10 16:33:18 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-10 16:33:18 --> UTF-8 Support Enabled
DEBUG - 2022-01-10 16:33:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-10 16:33:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-10 16:33:18 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-10 16:33:18 --> Total execution time: 0.0047
DEBUG - 2022-01-10 16:35:53 --> UTF-8 Support Enabled
DEBUG - 2022-01-10 16:35:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-10 16:35:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-10 16:35:53 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-10 16:35:53 --> UTF-8 Support Enabled
DEBUG - 2022-01-10 16:35:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-10 16:35:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-10 16:35:53 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-10 16:35:53 --> Total execution time: 0.0065
DEBUG - 2022-01-10 16:38:11 --> UTF-8 Support Enabled
DEBUG - 2022-01-10 16:38:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-10 16:38:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-10 16:38:11 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-10 16:38:11 --> UTF-8 Support Enabled
DEBUG - 2022-01-10 16:38:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-10 16:38:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-10 16:38:11 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-10 16:38:11 --> Total execution time: 0.0067
DEBUG - 2022-01-10 16:39:52 --> UTF-8 Support Enabled
DEBUG - 2022-01-10 16:39:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-10 16:39:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-10 16:39:52 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-10 16:39:52 --> UTF-8 Support Enabled
DEBUG - 2022-01-10 16:39:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-10 16:39:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-10 16:39:52 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-10 16:39:52 --> Total execution time: 0.0045
DEBUG - 2022-01-10 16:42:35 --> UTF-8 Support Enabled
DEBUG - 2022-01-10 16:42:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-10 16:42:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-10 16:42:35 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-10 16:42:35 --> UTF-8 Support Enabled
DEBUG - 2022-01-10 16:42:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-10 16:42:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-10 16:42:35 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-10 16:42:35 --> Total execution time: 0.0066
DEBUG - 2022-01-10 16:44:40 --> UTF-8 Support Enabled
DEBUG - 2022-01-10 16:44:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-10 16:44:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-10 16:44:40 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-10 16:44:40 --> UTF-8 Support Enabled
DEBUG - 2022-01-10 16:44:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-10 16:44:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-10 16:44:40 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-10 16:44:40 --> Total execution time: 0.0061
DEBUG - 2022-01-10 16:45:43 --> UTF-8 Support Enabled
DEBUG - 2022-01-10 16:45:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-10 16:45:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-10 16:45:43 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-10 16:45:43 --> UTF-8 Support Enabled
DEBUG - 2022-01-10 16:45:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-10 16:45:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-10 16:45:43 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-10 16:45:43 --> Total execution time: 0.0040
DEBUG - 2022-01-10 16:47:24 --> UTF-8 Support Enabled
DEBUG - 2022-01-10 16:47:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-10 16:47:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-10 16:47:24 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-10 16:47:24 --> Total execution time: 0.1425
DEBUG - 2022-01-10 16:49:15 --> UTF-8 Support Enabled
DEBUG - 2022-01-10 16:49:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-10 16:49:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-10 16:49:15 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-10 16:49:15 --> Total execution time: 0.0329
DEBUG - 2022-01-10 16:49:32 --> UTF-8 Support Enabled
DEBUG - 2022-01-10 16:49:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-10 16:49:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-10 16:49:32 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-10 16:49:33 --> Total execution time: 0.1278
DEBUG - 2022-01-10 16:49:35 --> UTF-8 Support Enabled
DEBUG - 2022-01-10 16:49:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-10 16:49:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-10 16:49:35 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-10 16:49:35 --> Total execution time: 0.0047
DEBUG - 2022-01-10 16:49:39 --> UTF-8 Support Enabled
DEBUG - 2022-01-10 16:49:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-10 16:49:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-10 16:49:39 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-10 16:49:40 --> Total execution time: 0.1569
DEBUG - 2022-01-10 16:50:30 --> UTF-8 Support Enabled
DEBUG - 2022-01-10 16:50:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-10 16:50:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-10 16:50:30 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-10 16:50:30 --> UTF-8 Support Enabled
DEBUG - 2022-01-10 16:50:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-10 16:50:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-10 16:50:30 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-10 16:50:30 --> Total execution time: 0.1428
DEBUG - 2022-01-10 16:51:19 --> UTF-8 Support Enabled
DEBUG - 2022-01-10 16:51:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-10 16:51:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-10 16:51:19 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-10 16:51:19 --> Total execution time: 0.0061
DEBUG - 2022-01-10 16:51:33 --> UTF-8 Support Enabled
DEBUG - 2022-01-10 16:51:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-10 16:51:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-10 16:51:33 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-10 16:51:33 --> Total execution time: 0.1319
DEBUG - 2022-01-10 16:51:36 --> UTF-8 Support Enabled
DEBUG - 2022-01-10 16:51:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-10 16:51:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-10 16:51:36 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-10 16:51:36 --> Total execution time: 0.0040
DEBUG - 2022-01-10 16:51:38 --> UTF-8 Support Enabled
DEBUG - 2022-01-10 16:51:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-10 16:51:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-10 16:51:38 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-10 16:51:39 --> Total execution time: 0.1109
DEBUG - 2022-01-10 16:52:35 --> UTF-8 Support Enabled
DEBUG - 2022-01-10 16:52:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-10 16:52:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-10 16:52:35 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-10 16:52:35 --> UTF-8 Support Enabled
DEBUG - 2022-01-10 16:52:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-10 16:52:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-10 16:52:35 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-10 16:52:36 --> Total execution time: 0.1150
DEBUG - 2022-01-10 16:53:42 --> UTF-8 Support Enabled
DEBUG - 2022-01-10 16:53:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-10 16:53:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-10 16:53:42 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-10 16:53:42 --> Total execution time: 0.0053
DEBUG - 2022-01-10 16:55:02 --> UTF-8 Support Enabled
DEBUG - 2022-01-10 16:55:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-10 16:55:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-10 16:55:02 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-10 16:55:02 --> UTF-8 Support Enabled
DEBUG - 2022-01-10 16:55:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-10 16:55:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-10 16:55:02 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-10 16:55:02 --> Total execution time: 0.0050
DEBUG - 2022-01-10 16:55:06 --> UTF-8 Support Enabled
DEBUG - 2022-01-10 16:55:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-10 16:55:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-10 16:55:06 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-10 16:55:06 --> Total execution time: 0.1716
DEBUG - 2022-01-10 16:57:24 --> UTF-8 Support Enabled
DEBUG - 2022-01-10 16:57:24 --> No URI present. Default controller set.
DEBUG - 2022-01-10 16:57:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-10 16:57:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-10 16:57:24 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-10 16:57:24 --> Total execution time: 0.0320
DEBUG - 2022-01-10 16:57:25 --> UTF-8 Support Enabled
DEBUG - 2022-01-10 16:57:25 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-01-10 16:57:25 --> 404 Page Not Found: Assets/https:
DEBUG - 2022-01-10 16:57:30 --> UTF-8 Support Enabled
DEBUG - 2022-01-10 16:57:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-10 16:57:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-10 16:57:30 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-10 16:57:30 --> UTF-8 Support Enabled
DEBUG - 2022-01-10 16:57:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-10 16:57:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-10 16:57:30 --> Total execution time: 0.0052
DEBUG - 2022-01-10 16:57:32 --> UTF-8 Support Enabled
DEBUG - 2022-01-10 16:57:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-10 16:57:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-10 16:57:32 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-10 16:57:32 --> Total execution time: 0.1233
DEBUG - 2022-01-10 16:57:41 --> UTF-8 Support Enabled
DEBUG - 2022-01-10 16:57:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-10 16:57:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-10 16:57:41 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-10 16:57:41 --> Total execution time: 0.1121
DEBUG - 2022-01-10 16:59:31 --> UTF-8 Support Enabled
DEBUG - 2022-01-10 16:59:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-10 16:59:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-10 16:59:31 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-10 16:59:31 --> Total execution time: 0.0326
DEBUG - 2022-01-10 17:01:13 --> UTF-8 Support Enabled
DEBUG - 2022-01-10 17:01:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-10 17:01:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-10 17:01:13 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-10 17:01:13 --> UTF-8 Support Enabled
DEBUG - 2022-01-10 17:01:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-10 17:01:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-10 17:01:13 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-10 17:01:13 --> Total execution time: 0.0051
DEBUG - 2022-01-10 17:01:16 --> UTF-8 Support Enabled
DEBUG - 2022-01-10 17:01:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-10 17:01:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-10 17:01:16 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-10 17:01:16 --> Total execution time: 0.1141
DEBUG - 2022-01-10 17:03:02 --> UTF-8 Support Enabled
DEBUG - 2022-01-10 17:03:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-10 17:03:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-10 17:03:02 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-10 17:03:02 --> Total execution time: 0.0321
DEBUG - 2022-01-10 17:03:03 --> UTF-8 Support Enabled
DEBUG - 2022-01-10 17:03:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-10 17:03:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-10 17:03:03 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-10 17:03:03 --> Total execution time: 0.0037
DEBUG - 2022-01-10 17:04:07 --> UTF-8 Support Enabled
DEBUG - 2022-01-10 17:04:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-10 17:04:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-10 17:04:07 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-10 17:04:07 --> UTF-8 Support Enabled
DEBUG - 2022-01-10 17:04:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-10 17:04:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-10 17:04:07 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-10 17:04:07 --> Total execution time: 0.0038
DEBUG - 2022-01-10 17:05:25 --> UTF-8 Support Enabled
DEBUG - 2022-01-10 17:05:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-10 17:05:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-10 17:05:25 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-10 17:05:25 --> UTF-8 Support Enabled
DEBUG - 2022-01-10 17:05:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-10 17:05:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-10 17:05:25 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-10 17:05:25 --> Total execution time: 0.0049
DEBUG - 2022-01-10 17:06:46 --> UTF-8 Support Enabled
DEBUG - 2022-01-10 17:06:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-10 17:06:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-10 17:06:46 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-10 17:06:46 --> UTF-8 Support Enabled
DEBUG - 2022-01-10 17:06:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-10 17:06:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-10 17:06:46 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-10 17:06:46 --> Total execution time: 0.0052
DEBUG - 2022-01-10 17:07:46 --> UTF-8 Support Enabled
DEBUG - 2022-01-10 17:07:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-10 17:07:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-10 17:07:46 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-10 17:07:46 --> UTF-8 Support Enabled
DEBUG - 2022-01-10 17:07:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-10 17:07:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-10 17:07:46 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-10 17:07:46 --> Total execution time: 0.0036
DEBUG - 2022-01-10 17:07:50 --> UTF-8 Support Enabled
DEBUG - 2022-01-10 17:07:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-10 17:07:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-10 17:07:50 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-10 17:07:50 --> Total execution time: 0.1139
DEBUG - 2022-01-10 17:08:34 --> UTF-8 Support Enabled
DEBUG - 2022-01-10 17:08:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-10 17:08:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-10 17:08:34 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-10 17:08:34 --> Total execution time: 0.0049
DEBUG - 2022-01-10 17:10:19 --> UTF-8 Support Enabled
DEBUG - 2022-01-10 17:10:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-10 17:10:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-10 17:10:19 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-10 17:10:19 --> UTF-8 Support Enabled
DEBUG - 2022-01-10 17:10:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-10 17:10:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-10 17:10:19 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-10 17:10:19 --> Total execution time: 0.0053
DEBUG - 2022-01-10 17:11:37 --> UTF-8 Support Enabled
DEBUG - 2022-01-10 17:11:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-10 17:11:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-10 17:11:37 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-10 17:11:37 --> UTF-8 Support Enabled
DEBUG - 2022-01-10 17:11:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-10 17:11:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-10 17:11:37 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-10 17:11:37 --> Total execution time: 0.0046
DEBUG - 2022-01-10 17:13:58 --> UTF-8 Support Enabled
DEBUG - 2022-01-10 17:13:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-10 17:13:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-10 17:13:58 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-10 17:13:58 --> UTF-8 Support Enabled
DEBUG - 2022-01-10 17:13:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-10 17:13:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-10 17:13:58 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-10 17:13:58 --> Total execution time: 0.0051
DEBUG - 2022-01-10 17:15:16 --> UTF-8 Support Enabled
DEBUG - 2022-01-10 17:15:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-10 17:15:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-10 17:15:16 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-10 17:15:16 --> UTF-8 Support Enabled
DEBUG - 2022-01-10 17:15:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-10 17:15:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-10 17:15:16 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-10 17:15:16 --> Total execution time: 0.0052
DEBUG - 2022-01-10 17:16:42 --> UTF-8 Support Enabled
DEBUG - 2022-01-10 17:16:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-10 17:16:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-10 17:16:42 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-10 17:16:42 --> UTF-8 Support Enabled
DEBUG - 2022-01-10 17:16:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-10 17:16:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-10 17:16:42 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-10 17:16:42 --> Total execution time: 0.0052
DEBUG - 2022-01-10 17:16:45 --> UTF-8 Support Enabled
DEBUG - 2022-01-10 17:16:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-10 17:16:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-10 17:16:45 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-10 17:16:45 --> Total execution time: 0.1153
DEBUG - 2022-01-10 17:17:25 --> UTF-8 Support Enabled
DEBUG - 2022-01-10 17:17:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-10 17:17:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-10 17:17:25 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-10 17:17:25 --> Total execution time: 0.0050
DEBUG - 2022-01-10 17:19:01 --> UTF-8 Support Enabled
DEBUG - 2022-01-10 17:19:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-10 17:19:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-10 17:19:01 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-10 17:19:01 --> UTF-8 Support Enabled
DEBUG - 2022-01-10 17:19:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-10 17:19:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-10 17:19:01 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-10 17:19:01 --> Total execution time: 0.0048
DEBUG - 2022-01-10 17:20:58 --> UTF-8 Support Enabled
DEBUG - 2022-01-10 17:20:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-10 17:20:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-10 17:20:58 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-10 17:20:58 --> UTF-8 Support Enabled
DEBUG - 2022-01-10 17:20:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-10 17:20:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-10 17:20:58 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-10 17:20:58 --> Total execution time: 0.0052
DEBUG - 2022-01-10 17:23:29 --> UTF-8 Support Enabled
DEBUG - 2022-01-10 17:23:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-10 17:23:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-10 17:23:29 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-10 17:23:29 --> UTF-8 Support Enabled
DEBUG - 2022-01-10 17:23:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-10 17:23:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-10 17:23:29 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-10 17:23:29 --> Total execution time: 0.0052
DEBUG - 2022-01-10 17:26:31 --> UTF-8 Support Enabled
DEBUG - 2022-01-10 17:26:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-10 17:26:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-10 17:26:31 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-10 17:26:31 --> UTF-8 Support Enabled
DEBUG - 2022-01-10 17:26:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-10 17:26:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-10 17:26:31 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-10 17:26:31 --> Total execution time: 0.0057
DEBUG - 2022-01-10 17:27:31 --> UTF-8 Support Enabled
DEBUG - 2022-01-10 17:27:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-10 17:27:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-10 17:27:31 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-10 17:27:31 --> UTF-8 Support Enabled
DEBUG - 2022-01-10 17:27:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-10 17:27:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-10 17:27:31 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-10 17:27:31 --> Total execution time: 0.0042
DEBUG - 2022-01-10 17:27:34 --> UTF-8 Support Enabled
DEBUG - 2022-01-10 17:27:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-10 17:27:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-10 17:27:34 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-10 17:27:35 --> Total execution time: 0.1180
DEBUG - 2022-01-10 17:30:47 --> UTF-8 Support Enabled
DEBUG - 2022-01-10 17:30:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-10 17:30:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-10 17:30:47 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-10 17:30:47 --> UTF-8 Support Enabled
DEBUG - 2022-01-10 17:30:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-10 17:30:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-10 17:30:47 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-10 17:30:47 --> Total execution time: 0.0032
DEBUG - 2022-01-10 17:30:50 --> UTF-8 Support Enabled
DEBUG - 2022-01-10 17:30:50 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-01-10 17:30:50 --> 404 Page Not Found: Assets/https:
