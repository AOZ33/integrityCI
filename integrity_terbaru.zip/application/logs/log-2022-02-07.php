<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

DEBUG - 2022-02-07 09:28:57 --> UTF-8 Support Enabled
DEBUG - 2022-02-07 09:28:57 --> No URI present. Default controller set.
DEBUG - 2022-02-07 09:28:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-07 09:28:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-07 09:28:57 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-02-07 09:28:57 --> Total execution time: 0.0309
DEBUG - 2022-02-07 09:28:57 --> UTF-8 Support Enabled
DEBUG - 2022-02-07 09:28:57 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-02-07 09:28:57 --> 404 Page Not Found: Assets/https:
DEBUG - 2022-02-07 09:34:45 --> UTF-8 Support Enabled
DEBUG - 2022-02-07 09:34:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-07 09:34:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-07 09:34:45 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-02-07 09:34:46 --> UTF-8 Support Enabled
DEBUG - 2022-02-07 09:34:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-07 09:34:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-07 09:34:46 --> Total execution time: 0.0058
DEBUG - 2022-02-07 09:34:47 --> UTF-8 Support Enabled
DEBUG - 2022-02-07 09:34:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-07 09:34:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-07 09:34:47 --> Form_validation class already loaded. Second attempt ignored.
ERROR - 2022-02-07 09:34:48 --> Severity: Error --> Allowed memory size of 268435456 bytes exhausted (tried to allocate 159207240 bytes) /home/dunr4521/public_html/integrity/system/core/Loader.php 996
DEBUG - 2022-02-07 09:34:50 --> UTF-8 Support Enabled
DEBUG - 2022-02-07 09:34:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-07 09:34:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-07 09:34:50 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-02-07 09:34:50 --> Total execution time: 0.0041
DEBUG - 2022-02-07 09:34:50 --> UTF-8 Support Enabled
DEBUG - 2022-02-07 09:34:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-07 09:34:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-07 09:34:50 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-02-07 09:34:50 --> Total execution time: 0.0035
DEBUG - 2022-02-07 09:34:51 --> UTF-8 Support Enabled
DEBUG - 2022-02-07 09:34:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-07 09:34:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-07 09:34:51 --> Form_validation class already loaded. Second attempt ignored.
ERROR - 2022-02-07 09:34:51 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near 'ORDER BY `user_access_menu`.`menu_id` ASC' at line 5 - Invalid query: SELECT `user_menu`.`id`,`menu` 
                    FROM `user_menu` JOIN `user_access_menu` 
                    ON `user_menu`.`id` = `user_access_menu`.`menu_id` 
                    WHERE `user_access_menu`.`role_id` = 
                    ORDER BY `user_access_menu`.`menu_id` ASC
                    
ERROR - 2022-02-07 09:34:51 --> Severity: error --> Exception: Call to a member function result_array() on bool /home/dunr4521/public_html/integrity/application/views/templates/sidebar.php 23
DEBUG - 2022-02-07 09:34:57 --> UTF-8 Support Enabled
DEBUG - 2022-02-07 09:34:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-07 09:34:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-07 09:34:57 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-02-07 09:34:57 --> Total execution time: 0.0033
DEBUG - 2022-02-07 09:34:58 --> UTF-8 Support Enabled
DEBUG - 2022-02-07 09:34:58 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-02-07 09:34:58 --> 404 Page Not Found: Assets/https:
DEBUG - 2022-02-07 09:35:22 --> UTF-8 Support Enabled
DEBUG - 2022-02-07 09:35:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-07 09:35:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-07 09:35:22 --> Form_validation class already loaded. Second attempt ignored.
ERROR - 2022-02-07 09:35:22 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near 'ORDER BY `user_access_menu`.`menu_id` ASC' at line 5 - Invalid query: SELECT `user_menu`.`id`,`menu` 
                    FROM `user_menu` JOIN `user_access_menu` 
                    ON `user_menu`.`id` = `user_access_menu`.`menu_id` 
                    WHERE `user_access_menu`.`role_id` = 
                    ORDER BY `user_access_menu`.`menu_id` ASC
                    
ERROR - 2022-02-07 09:35:22 --> Severity: error --> Exception: Call to a member function result_array() on bool /home/dunr4521/public_html/integrity/application/views/templates/sidebar.php 23
DEBUG - 2022-02-07 10:39:24 --> UTF-8 Support Enabled
DEBUG - 2022-02-07 10:39:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-07 10:39:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-07 10:39:24 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-02-07 10:39:24 --> UTF-8 Support Enabled
DEBUG - 2022-02-07 10:39:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-07 10:39:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-07 10:39:24 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-02-07 10:39:24 --> Total execution time: 0.0069
DEBUG - 2022-02-07 10:44:27 --> UTF-8 Support Enabled
DEBUG - 2022-02-07 10:44:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-07 10:44:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-07 10:44:27 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-02-07 10:44:27 --> UTF-8 Support Enabled
DEBUG - 2022-02-07 10:44:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-07 10:44:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-07 10:44:27 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-02-07 10:44:27 --> Total execution time: 0.0062
DEBUG - 2022-02-07 10:51:24 --> UTF-8 Support Enabled
DEBUG - 2022-02-07 10:51:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-07 10:51:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-07 10:51:24 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-02-07 10:51:25 --> UTF-8 Support Enabled
DEBUG - 2022-02-07 10:51:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-07 10:51:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-07 10:51:25 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-02-07 10:51:25 --> Total execution time: 0.0058
DEBUG - 2022-02-07 10:58:24 --> UTF-8 Support Enabled
DEBUG - 2022-02-07 10:58:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-07 10:58:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-07 10:58:24 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-02-07 10:58:24 --> UTF-8 Support Enabled
DEBUG - 2022-02-07 10:58:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-07 10:58:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-07 10:58:24 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-02-07 10:58:24 --> Total execution time: 0.0056
DEBUG - 2022-02-07 11:07:32 --> UTF-8 Support Enabled
DEBUG - 2022-02-07 11:07:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-07 11:07:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-07 11:07:32 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-02-07 11:07:32 --> UTF-8 Support Enabled
DEBUG - 2022-02-07 11:07:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-07 11:07:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-07 11:07:32 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-02-07 11:07:32 --> Total execution time: 0.0061
DEBUG - 2022-02-07 11:19:41 --> UTF-8 Support Enabled
DEBUG - 2022-02-07 11:19:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-07 11:19:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-07 11:19:41 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-02-07 11:19:41 --> UTF-8 Support Enabled
DEBUG - 2022-02-07 11:19:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-07 11:19:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-07 11:19:41 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-02-07 11:19:41 --> Total execution time: 0.0063
DEBUG - 2022-02-07 11:39:20 --> UTF-8 Support Enabled
DEBUG - 2022-02-07 11:39:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-07 11:39:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-07 11:39:20 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-02-07 11:39:21 --> UTF-8 Support Enabled
DEBUG - 2022-02-07 11:39:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-07 11:39:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-07 11:39:21 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-02-07 11:39:21 --> Total execution time: 0.0063
DEBUG - 2022-02-07 11:44:58 --> UTF-8 Support Enabled
DEBUG - 2022-02-07 11:44:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-07 11:44:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-07 11:44:58 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-02-07 11:44:58 --> UTF-8 Support Enabled
DEBUG - 2022-02-07 11:44:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-07 11:44:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-07 11:44:58 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-02-07 11:44:58 --> Total execution time: 0.0061
DEBUG - 2022-02-07 11:50:41 --> UTF-8 Support Enabled
DEBUG - 2022-02-07 11:50:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-07 11:50:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-07 11:50:41 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-02-07 11:50:41 --> UTF-8 Support Enabled
DEBUG - 2022-02-07 11:50:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-07 11:50:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-07 11:50:41 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-02-07 11:50:41 --> Total execution time: 0.0058
DEBUG - 2022-02-07 13:34:13 --> UTF-8 Support Enabled
DEBUG - 2022-02-07 13:34:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-07 13:34:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-07 13:34:13 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-02-07 13:34:13 --> UTF-8 Support Enabled
DEBUG - 2022-02-07 13:34:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-07 13:34:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-07 13:34:13 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-02-07 13:34:13 --> Total execution time: 0.0066
DEBUG - 2022-02-07 14:08:27 --> UTF-8 Support Enabled
DEBUG - 2022-02-07 14:08:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-07 14:08:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-07 14:08:27 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-02-07 14:08:29 --> UTF-8 Support Enabled
DEBUG - 2022-02-07 14:08:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-07 14:08:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-07 14:08:29 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-02-07 14:08:29 --> Total execution time: 0.0069
DEBUG - 2022-02-07 14:26:03 --> UTF-8 Support Enabled
DEBUG - 2022-02-07 14:26:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-07 14:26:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-07 14:26:03 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-02-07 14:26:03 --> UTF-8 Support Enabled
DEBUG - 2022-02-07 14:26:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-07 14:26:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-07 14:26:03 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-02-07 14:26:03 --> Total execution time: 0.0058
DEBUG - 2022-02-07 14:29:17 --> UTF-8 Support Enabled
DEBUG - 2022-02-07 14:29:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-07 14:29:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-07 14:29:17 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-02-07 14:29:19 --> UTF-8 Support Enabled
DEBUG - 2022-02-07 14:29:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-07 14:29:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-07 14:29:19 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-02-07 14:29:19 --> Total execution time: 0.0063
DEBUG - 2022-02-07 14:41:30 --> UTF-8 Support Enabled
DEBUG - 2022-02-07 14:41:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-07 14:41:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-07 14:41:30 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-02-07 14:41:30 --> UTF-8 Support Enabled
DEBUG - 2022-02-07 14:41:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-07 14:41:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-07 14:41:30 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-02-07 14:41:30 --> Total execution time: 0.0059
DEBUG - 2022-02-07 14:48:08 --> UTF-8 Support Enabled
DEBUG - 2022-02-07 14:48:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-07 14:48:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-07 14:48:08 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-02-07 14:48:08 --> UTF-8 Support Enabled
DEBUG - 2022-02-07 14:48:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-07 14:48:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-07 14:48:08 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-02-07 14:48:08 --> Total execution time: 0.0059
DEBUG - 2022-02-07 14:52:57 --> UTF-8 Support Enabled
DEBUG - 2022-02-07 14:52:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-07 14:52:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-07 14:52:57 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-02-07 14:52:57 --> UTF-8 Support Enabled
DEBUG - 2022-02-07 14:52:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-07 14:52:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-07 14:52:57 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-02-07 14:52:57 --> Total execution time: 0.0057
DEBUG - 2022-02-07 14:55:40 --> UTF-8 Support Enabled
DEBUG - 2022-02-07 14:55:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-07 14:55:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-07 14:55:40 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-02-07 14:55:40 --> UTF-8 Support Enabled
DEBUG - 2022-02-07 14:55:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-07 14:55:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-07 14:55:40 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-02-07 14:55:40 --> Total execution time: 0.0051
DEBUG - 2022-02-07 15:31:55 --> UTF-8 Support Enabled
DEBUG - 2022-02-07 15:31:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-07 15:31:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-07 15:31:55 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-02-07 15:31:55 --> UTF-8 Support Enabled
DEBUG - 2022-02-07 15:31:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-07 15:31:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-07 15:31:55 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-02-07 15:31:55 --> Total execution time: 0.0067
DEBUG - 2022-02-07 15:37:24 --> UTF-8 Support Enabled
DEBUG - 2022-02-07 15:37:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-07 15:37:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-07 15:37:24 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-02-07 15:37:24 --> UTF-8 Support Enabled
DEBUG - 2022-02-07 15:37:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-07 15:37:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-07 15:37:24 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-02-07 15:37:24 --> Total execution time: 0.0059
DEBUG - 2022-02-07 15:48:34 --> UTF-8 Support Enabled
DEBUG - 2022-02-07 15:48:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-07 15:48:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-07 15:48:34 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-02-07 15:48:34 --> UTF-8 Support Enabled
DEBUG - 2022-02-07 15:48:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-07 15:48:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-07 15:48:34 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-02-07 15:48:34 --> Total execution time: 0.0063
DEBUG - 2022-02-07 15:56:39 --> UTF-8 Support Enabled
DEBUG - 2022-02-07 15:56:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-07 15:56:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-07 15:56:39 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-02-07 15:56:39 --> UTF-8 Support Enabled
DEBUG - 2022-02-07 15:56:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-07 15:56:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-07 15:56:39 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-02-07 15:56:39 --> Total execution time: 0.0053
DEBUG - 2022-02-07 16:01:51 --> UTF-8 Support Enabled
DEBUG - 2022-02-07 16:01:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-07 16:01:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-07 16:01:51 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-02-07 16:01:51 --> UTF-8 Support Enabled
DEBUG - 2022-02-07 16:01:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-07 16:01:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-07 16:01:51 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-02-07 16:01:51 --> Total execution time: 0.0056
DEBUG - 2022-02-07 16:33:10 --> UTF-8 Support Enabled
DEBUG - 2022-02-07 16:33:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-07 16:33:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-07 16:33:10 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-02-07 16:33:10 --> UTF-8 Support Enabled
DEBUG - 2022-02-07 16:33:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-07 16:33:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-07 16:33:10 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-02-07 16:33:10 --> Total execution time: 0.0068
DEBUG - 2022-02-07 16:35:07 --> UTF-8 Support Enabled
DEBUG - 2022-02-07 16:35:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-07 16:35:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-07 16:35:07 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-02-07 16:35:07 --> UTF-8 Support Enabled
DEBUG - 2022-02-07 16:35:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-07 16:35:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-07 16:35:07 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-02-07 16:35:07 --> Total execution time: 0.0039
DEBUG - 2022-02-07 16:39:20 --> UTF-8 Support Enabled
DEBUG - 2022-02-07 16:39:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-07 16:39:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-07 16:39:20 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-02-07 16:39:20 --> UTF-8 Support Enabled
DEBUG - 2022-02-07 16:39:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-07 16:39:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-07 16:39:20 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-02-07 16:39:20 --> Total execution time: 0.0058
DEBUG - 2022-02-07 16:42:31 --> UTF-8 Support Enabled
DEBUG - 2022-02-07 16:42:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-07 16:42:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-07 16:42:31 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-02-07 16:42:31 --> UTF-8 Support Enabled
DEBUG - 2022-02-07 16:42:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-07 16:42:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-07 16:42:31 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-02-07 16:42:31 --> Total execution time: 0.0057
DEBUG - 2022-02-07 16:47:12 --> UTF-8 Support Enabled
DEBUG - 2022-02-07 16:47:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-07 16:47:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-07 16:47:12 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-02-07 16:47:12 --> UTF-8 Support Enabled
DEBUG - 2022-02-07 16:47:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-07 16:47:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-07 16:47:12 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-02-07 16:47:12 --> Total execution time: 0.0052
DEBUG - 2022-02-07 16:49:41 --> UTF-8 Support Enabled
DEBUG - 2022-02-07 16:49:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-07 16:49:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-07 16:49:41 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-02-07 16:49:41 --> UTF-8 Support Enabled
DEBUG - 2022-02-07 16:49:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-07 16:49:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-07 16:49:41 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-02-07 16:49:41 --> Total execution time: 0.0043
DEBUG - 2022-02-07 16:52:00 --> UTF-8 Support Enabled
DEBUG - 2022-02-07 16:52:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-07 16:52:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-07 16:52:00 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-02-07 16:52:00 --> UTF-8 Support Enabled
DEBUG - 2022-02-07 16:52:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-07 16:52:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-07 16:52:00 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-02-07 16:52:00 --> Total execution time: 0.0043
DEBUG - 2022-02-07 16:54:33 --> UTF-8 Support Enabled
DEBUG - 2022-02-07 16:54:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-07 16:54:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-07 16:54:33 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-02-07 16:54:33 --> UTF-8 Support Enabled
DEBUG - 2022-02-07 16:54:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-07 16:54:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-07 16:54:33 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-02-07 16:54:33 --> Total execution time: 0.0054
DEBUG - 2022-02-07 16:57:18 --> UTF-8 Support Enabled
DEBUG - 2022-02-07 16:57:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-07 16:57:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-07 16:57:18 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-02-07 16:57:18 --> UTF-8 Support Enabled
DEBUG - 2022-02-07 16:57:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-07 16:57:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-07 16:57:18 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-02-07 16:57:18 --> Total execution time: 0.0038
DEBUG - 2022-02-07 17:00:25 --> UTF-8 Support Enabled
DEBUG - 2022-02-07 17:00:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-07 17:00:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-07 17:00:25 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-02-07 17:00:25 --> UTF-8 Support Enabled
DEBUG - 2022-02-07 17:00:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-07 17:00:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-07 17:00:25 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-02-07 17:00:25 --> Total execution time: 0.0062
DEBUG - 2022-02-07 17:03:29 --> UTF-8 Support Enabled
DEBUG - 2022-02-07 17:03:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-07 17:03:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-07 17:03:29 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-02-07 17:03:29 --> UTF-8 Support Enabled
DEBUG - 2022-02-07 17:03:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-07 17:03:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-07 17:03:29 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-02-07 17:03:29 --> Total execution time: 0.0048
DEBUG - 2022-02-07 17:06:48 --> UTF-8 Support Enabled
DEBUG - 2022-02-07 17:06:48 --> No URI present. Default controller set.
DEBUG - 2022-02-07 17:06:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-07 17:06:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-07 17:06:48 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-02-07 17:06:48 --> Total execution time: 0.0048
DEBUG - 2022-02-07 17:06:48 --> UTF-8 Support Enabled
DEBUG - 2022-02-07 17:06:48 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-02-07 17:06:48 --> 404 Page Not Found: Robotstxt/index
DEBUG - 2022-02-07 17:06:48 --> UTF-8 Support Enabled
DEBUG - 2022-02-07 17:06:48 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-02-07 17:06:48 --> 404 Page Not Found: Robotstxt/index
DEBUG - 2022-02-07 17:06:48 --> UTF-8 Support Enabled
DEBUG - 2022-02-07 17:06:48 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-02-07 17:06:48 --> 404 Page Not Found: Assets/https:
DEBUG - 2022-02-07 17:06:56 --> UTF-8 Support Enabled
DEBUG - 2022-02-07 17:06:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-07 17:06:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-07 17:06:56 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-02-07 17:06:56 --> UTF-8 Support Enabled
DEBUG - 2022-02-07 17:06:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-07 17:06:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-07 17:06:56 --> Total execution time: 0.0041
DEBUG - 2022-02-07 17:07:06 --> UTF-8 Support Enabled
DEBUG - 2022-02-07 17:07:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-07 17:07:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-07 17:07:06 --> Form_validation class already loaded. Second attempt ignored.
ERROR - 2022-02-07 17:07:07 --> Severity: Error --> Allowed memory size of 268435456 bytes exhausted (tried to allocate 163098672 bytes) /home/dunr4521/public_html/integrity/system/core/Loader.php 996
DEBUG - 2022-02-07 17:07:26 --> UTF-8 Support Enabled
DEBUG - 2022-02-07 17:07:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-07 17:07:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-07 17:07:26 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-02-07 17:07:26 --> UTF-8 Support Enabled
DEBUG - 2022-02-07 17:07:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-07 17:07:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-07 17:07:26 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-02-07 17:07:26 --> Total execution time: 0.0038
DEBUG - 2022-02-07 17:07:41 --> UTF-8 Support Enabled
DEBUG - 2022-02-07 17:07:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-07 17:07:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-07 17:07:41 --> Total execution time: 0.0050
DEBUG - 2022-02-07 17:07:42 --> UTF-8 Support Enabled
DEBUG - 2022-02-07 17:07:42 --> No URI present. Default controller set.
DEBUG - 2022-02-07 17:07:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-07 17:07:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-07 17:07:42 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-02-07 17:07:42 --> Total execution time: 0.0031
DEBUG - 2022-02-07 17:07:43 --> UTF-8 Support Enabled
DEBUG - 2022-02-07 17:07:43 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-02-07 17:07:43 --> 404 Page Not Found: Assets/https:
DEBUG - 2022-02-07 17:07:47 --> UTF-8 Support Enabled
DEBUG - 2022-02-07 17:07:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-07 17:07:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-07 17:07:47 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-02-07 17:07:47 --> UTF-8 Support Enabled
DEBUG - 2022-02-07 17:07:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-07 17:07:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-07 17:07:47 --> Total execution time: 0.0032
DEBUG - 2022-02-07 17:07:49 --> UTF-8 Support Enabled
DEBUG - 2022-02-07 17:07:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-07 17:07:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-07 17:07:49 --> Total execution time: 0.0039
DEBUG - 2022-02-07 17:07:52 --> UTF-8 Support Enabled
DEBUG - 2022-02-07 17:07:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-07 17:07:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-07 17:07:52 --> Total execution time: 0.0036
DEBUG - 2022-02-07 17:08:52 --> UTF-8 Support Enabled
DEBUG - 2022-02-07 17:08:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-07 17:08:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-07 17:08:52 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-02-07 17:08:52 --> UTF-8 Support Enabled
DEBUG - 2022-02-07 17:08:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-07 17:08:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-07 17:08:52 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-02-07 17:08:52 --> Total execution time: 0.0037
DEBUG - 2022-02-07 17:11:36 --> UTF-8 Support Enabled
DEBUG - 2022-02-07 17:11:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-07 17:11:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-07 17:11:37 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-02-07 17:11:37 --> UTF-8 Support Enabled
DEBUG - 2022-02-07 17:11:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-07 17:11:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-07 17:11:37 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-02-07 17:11:37 --> Total execution time: 0.0053
DEBUG - 2022-02-07 17:13:38 --> UTF-8 Support Enabled
DEBUG - 2022-02-07 17:13:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-07 17:13:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-07 17:13:38 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-02-07 17:13:38 --> UTF-8 Support Enabled
DEBUG - 2022-02-07 17:13:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-07 17:13:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-07 17:13:38 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-02-07 17:13:38 --> Total execution time: 0.0053
DEBUG - 2022-02-07 17:15:42 --> UTF-8 Support Enabled
DEBUG - 2022-02-07 17:15:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-07 17:15:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-07 17:15:42 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-02-07 17:15:42 --> UTF-8 Support Enabled
DEBUG - 2022-02-07 17:15:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-07 17:15:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-07 17:15:42 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-02-07 17:15:42 --> Total execution time: 0.0039
DEBUG - 2022-02-07 17:18:19 --> UTF-8 Support Enabled
DEBUG - 2022-02-07 17:18:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-07 17:18:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-07 17:18:19 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-02-07 17:18:19 --> UTF-8 Support Enabled
DEBUG - 2022-02-07 17:18:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-07 17:18:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-07 17:18:19 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-02-07 17:18:19 --> Total execution time: 0.0045
DEBUG - 2022-02-07 17:20:41 --> UTF-8 Support Enabled
DEBUG - 2022-02-07 17:20:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-07 17:20:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-07 17:20:41 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-02-07 17:20:41 --> UTF-8 Support Enabled
DEBUG - 2022-02-07 17:20:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-07 17:20:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-07 17:20:41 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-02-07 17:20:41 --> Total execution time: 0.0038
DEBUG - 2022-02-07 17:23:11 --> UTF-8 Support Enabled
DEBUG - 2022-02-07 17:23:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-07 17:23:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-07 17:23:11 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-02-07 17:23:11 --> UTF-8 Support Enabled
DEBUG - 2022-02-07 17:23:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-07 17:23:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-07 17:23:11 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-02-07 17:23:11 --> Total execution time: 0.0050
DEBUG - 2022-02-07 17:31:35 --> UTF-8 Support Enabled
DEBUG - 2022-02-07 17:31:35 --> No URI present. Default controller set.
DEBUG - 2022-02-07 17:31:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-07 17:31:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-07 17:31:35 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-02-07 17:31:35 --> Total execution time: 0.0043
DEBUG - 2022-02-07 17:31:35 --> UTF-8 Support Enabled
DEBUG - 2022-02-07 17:31:35 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-02-07 17:31:35 --> 404 Page Not Found: Assets/https:
DEBUG - 2022-02-07 17:31:52 --> UTF-8 Support Enabled
DEBUG - 2022-02-07 17:31:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-07 17:31:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-07 17:31:52 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-02-07 17:31:52 --> UTF-8 Support Enabled
DEBUG - 2022-02-07 17:31:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-07 17:31:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-07 17:31:52 --> Total execution time: 0.0052
DEBUG - 2022-02-07 17:31:56 --> UTF-8 Support Enabled
DEBUG - 2022-02-07 17:31:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-07 17:31:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-07 17:31:56 --> Form_validation class already loaded. Second attempt ignored.
ERROR - 2022-02-07 17:31:56 --> Severity: Error --> Allowed memory size of 268435456 bytes exhausted (tried to allocate 164070208 bytes) /home/dunr4521/public_html/integrity/system/core/Loader.php 996
DEBUG - 2022-02-07 17:32:24 --> UTF-8 Support Enabled
DEBUG - 2022-02-07 17:32:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-07 17:32:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-07 17:32:24 --> Total execution time: 0.0043
DEBUG - 2022-02-07 17:32:38 --> UTF-8 Support Enabled
DEBUG - 2022-02-07 17:32:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-07 17:32:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-07 17:32:38 --> Total execution time: 0.0033
DEBUG - 2022-02-07 17:32:44 --> UTF-8 Support Enabled
DEBUG - 2022-02-07 17:32:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-07 17:32:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-07 17:32:44 --> Form_validation class already loaded. Second attempt ignored.
ERROR - 2022-02-07 17:32:45 --> Severity: Error --> Allowed memory size of 268435456 bytes exhausted (tried to allocate 164070208 bytes) /home/dunr4521/public_html/integrity/system/core/Loader.php 996
DEBUG - 2022-02-07 17:33:32 --> UTF-8 Support Enabled
DEBUG - 2022-02-07 17:33:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-07 17:33:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-07 17:33:32 --> Form_validation class already loaded. Second attempt ignored.
ERROR - 2022-02-07 17:33:32 --> Severity: Error --> Allowed memory size of 268435456 bytes exhausted (tried to allocate 164070208 bytes) /home/dunr4521/public_html/integrity/system/core/Loader.php 996
DEBUG - 2022-02-07 17:34:18 --> UTF-8 Support Enabled
DEBUG - 2022-02-07 17:34:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-07 17:34:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-07 17:34:18 --> Form_validation class already loaded. Second attempt ignored.
ERROR - 2022-02-07 17:34:19 --> Severity: Error --> Allowed memory size of 268435456 bytes exhausted (tried to allocate 164070208 bytes) /home/dunr4521/public_html/integrity/system/core/Loader.php 996
DEBUG - 2022-02-07 17:35:38 --> UTF-8 Support Enabled
DEBUG - 2022-02-07 17:35:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-07 17:35:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-07 17:35:38 --> Form_validation class already loaded. Second attempt ignored.
ERROR - 2022-02-07 17:35:39 --> Severity: Error --> Allowed memory size of 268435456 bytes exhausted (tried to allocate 164070208 bytes) /home/dunr4521/public_html/integrity/system/core/Loader.php 996
DEBUG - 2022-02-07 17:57:47 --> UTF-8 Support Enabled
DEBUG - 2022-02-07 17:57:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-07 17:57:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-07 17:57:47 --> Form_validation class already loaded. Second attempt ignored.
ERROR - 2022-02-07 17:57:47 --> Severity: Error --> Allowed memory size of 268435456 bytes exhausted (tried to allocate 164070208 bytes) /home/dunr4521/public_html/integrity/system/core/Loader.php 996
