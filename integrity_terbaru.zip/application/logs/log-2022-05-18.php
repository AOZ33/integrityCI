<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

DEBUG - 2022-05-18 03:35:38 --> UTF-8 Support Enabled
DEBUG - 2022-05-18 03:35:38 --> No URI present. Default controller set.
DEBUG - 2022-05-18 03:35:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-18 03:35:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-05-18 03:35:38 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-05-18 03:35:38 --> Total execution time: 0.0556
DEBUG - 2022-05-18 03:35:38 --> UTF-8 Support Enabled
DEBUG - 2022-05-18 03:35:38 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-05-18 03:35:38 --> 404 Page Not Found: Assets/https:
DEBUG - 2022-05-18 03:35:38 --> UTF-8 Support Enabled
DEBUG - 2022-05-18 03:35:38 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-05-18 03:35:38 --> 404 Page Not Found: Js/jquery.min.js
DEBUG - 2022-05-18 03:35:38 --> UTF-8 Support Enabled
DEBUG - 2022-05-18 03:35:38 --> UTF-8 Support Enabled
DEBUG - 2022-05-18 03:35:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-18 03:35:38 --> UTF-8 Support Enabled
ERROR - 2022-05-18 03:35:38 --> 404 Page Not Found: Js/main.js
DEBUG - 2022-05-18 03:35:38 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-05-18 03:35:38 --> 404 Page Not Found: Js/popper.js
DEBUG - 2022-05-18 03:35:38 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-05-18 03:35:38 --> 404 Page Not Found: Js/bootstrap.min.js
DEBUG - 2022-05-18 03:35:38 --> UTF-8 Support Enabled
DEBUG - 2022-05-18 03:35:38 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-05-18 03:35:38 --> 404 Page Not Found: Faviconico/index
DEBUG - 2022-05-18 03:35:39 --> UTF-8 Support Enabled
DEBUG - 2022-05-18 03:35:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-18 03:35:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-05-18 03:35:39 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-05-18 03:35:39 --> UTF-8 Support Enabled
DEBUG - 2022-05-18 03:35:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-18 03:35:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-05-18 03:35:39 --> Total execution time: 0.0070
DEBUG - 2022-05-18 03:48:57 --> UTF-8 Support Enabled
DEBUG - 2022-05-18 03:48:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-18 03:48:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-05-18 03:48:57 --> Total execution time: 0.0453
DEBUG - 2022-05-18 03:49:00 --> UTF-8 Support Enabled
DEBUG - 2022-05-18 03:49:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-18 03:49:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-05-18 03:49:00 --> Total execution time: 0.0055
DEBUG - 2022-05-18 03:49:02 --> UTF-8 Support Enabled
DEBUG - 2022-05-18 03:49:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-18 03:49:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-05-18 03:49:02 --> Total execution time: 0.0024
DEBUG - 2022-05-18 03:49:05 --> UTF-8 Support Enabled
DEBUG - 2022-05-18 03:49:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-18 03:49:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-05-18 03:49:05 --> Total execution time: 0.0033
DEBUG - 2022-05-18 03:49:06 --> UTF-8 Support Enabled
DEBUG - 2022-05-18 03:49:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-18 03:49:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-05-18 03:49:06 --> Total execution time: 0.0026
DEBUG - 2022-05-18 04:31:34 --> UTF-8 Support Enabled
DEBUG - 2022-05-18 04:31:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-18 04:31:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-05-18 04:31:34 --> Form_validation class already loaded. Second attempt ignored.
ERROR - 2022-05-18 04:31:34 --> Severity: Warning --> Invalid argument supplied for foreach() /home/nsnmt.com/integrity/application/views/data/index.php 505
ERROR - 2022-05-18 04:31:34 --> Severity: Warning --> Invalid argument supplied for foreach() /home/nsnmt.com/integrity/application/views/data/index.php 505
ERROR - 2022-05-18 04:31:34 --> Severity: Warning --> Invalid argument supplied for foreach() /home/nsnmt.com/integrity/application/views/data/index.php 505
ERROR - 2022-05-18 04:31:34 --> Severity: Warning --> Invalid argument supplied for foreach() /home/nsnmt.com/integrity/application/views/data/index.php 505
ERROR - 2022-05-18 04:31:34 --> Severity: Warning --> Invalid argument supplied for foreach() /home/nsnmt.com/integrity/application/views/data/index.php 505
ERROR - 2022-05-18 04:31:34 --> Severity: Warning --> Invalid argument supplied for foreach() /home/nsnmt.com/integrity/application/views/data/index.php 505
ERROR - 2022-05-18 04:31:34 --> Severity: Warning --> Invalid argument supplied for foreach() /home/nsnmt.com/integrity/application/views/data/index.php 505
ERROR - 2022-05-18 04:31:34 --> Severity: Warning --> Invalid argument supplied for foreach() /home/nsnmt.com/integrity/application/views/data/index.php 505
ERROR - 2022-05-18 04:31:34 --> Severity: Warning --> Invalid argument supplied for foreach() /home/nsnmt.com/integrity/application/views/data/index.php 505
ERROR - 2022-05-18 04:31:34 --> Severity: Warning --> Invalid argument supplied for foreach() /home/nsnmt.com/integrity/application/views/data/index.php 505
ERROR - 2022-05-18 04:31:34 --> Severity: Warning --> Invalid argument supplied for foreach() /home/nsnmt.com/integrity/application/views/data/index.php 505
ERROR - 2022-05-18 04:31:34 --> Severity: Warning --> Invalid argument supplied for foreach() /home/nsnmt.com/integrity/application/views/data/index.php 505
DEBUG - 2022-05-18 04:31:34 --> Total execution time: 0.0636
DEBUG - 2022-05-18 04:57:01 --> UTF-8 Support Enabled
DEBUG - 2022-05-18 04:57:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-18 04:57:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-05-18 04:57:01 --> Form_validation class already loaded. Second attempt ignored.
ERROR - 2022-05-18 04:57:01 --> Severity: Warning --> Invalid argument supplied for foreach() /home/nsnmt.com/integrity/application/views/data/index.php 505
ERROR - 2022-05-18 04:57:01 --> Severity: Warning --> Invalid argument supplied for foreach() /home/nsnmt.com/integrity/application/views/data/index.php 505
ERROR - 2022-05-18 04:57:01 --> Severity: Warning --> Invalid argument supplied for foreach() /home/nsnmt.com/integrity/application/views/data/index.php 505
ERROR - 2022-05-18 04:57:01 --> Severity: Warning --> Invalid argument supplied for foreach() /home/nsnmt.com/integrity/application/views/data/index.php 505
ERROR - 2022-05-18 04:57:01 --> Severity: Warning --> Invalid argument supplied for foreach() /home/nsnmt.com/integrity/application/views/data/index.php 505
ERROR - 2022-05-18 04:57:01 --> Severity: Warning --> Invalid argument supplied for foreach() /home/nsnmt.com/integrity/application/views/data/index.php 505
ERROR - 2022-05-18 04:57:01 --> Severity: Warning --> Invalid argument supplied for foreach() /home/nsnmt.com/integrity/application/views/data/index.php 505
ERROR - 2022-05-18 04:57:01 --> Severity: Warning --> Invalid argument supplied for foreach() /home/nsnmt.com/integrity/application/views/data/index.php 505
ERROR - 2022-05-18 04:57:01 --> Severity: Warning --> Invalid argument supplied for foreach() /home/nsnmt.com/integrity/application/views/data/index.php 505
ERROR - 2022-05-18 04:57:01 --> Severity: Warning --> Invalid argument supplied for foreach() /home/nsnmt.com/integrity/application/views/data/index.php 505
ERROR - 2022-05-18 04:57:01 --> Severity: Warning --> Invalid argument supplied for foreach() /home/nsnmt.com/integrity/application/views/data/index.php 505
ERROR - 2022-05-18 04:57:01 --> Severity: Warning --> Invalid argument supplied for foreach() /home/nsnmt.com/integrity/application/views/data/index.php 505
DEBUG - 2022-05-18 04:57:01 --> Total execution time: 0.0567
DEBUG - 2022-05-18 05:04:27 --> UTF-8 Support Enabled
DEBUG - 2022-05-18 05:04:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-18 05:04:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-05-18 05:04:27 --> Form_validation class already loaded. Second attempt ignored.
ERROR - 2022-05-18 05:04:27 --> Severity: Warning --> Invalid argument supplied for foreach() /home/nsnmt.com/integrity/application/views/data/index.php 505
ERROR - 2022-05-18 05:04:27 --> Severity: Warning --> Invalid argument supplied for foreach() /home/nsnmt.com/integrity/application/views/data/index.php 505
ERROR - 2022-05-18 05:04:27 --> Severity: Warning --> Invalid argument supplied for foreach() /home/nsnmt.com/integrity/application/views/data/index.php 505
ERROR - 2022-05-18 05:04:27 --> Severity: Warning --> Invalid argument supplied for foreach() /home/nsnmt.com/integrity/application/views/data/index.php 505
ERROR - 2022-05-18 05:04:27 --> Severity: Warning --> Invalid argument supplied for foreach() /home/nsnmt.com/integrity/application/views/data/index.php 505
ERROR - 2022-05-18 05:04:27 --> Severity: Warning --> Invalid argument supplied for foreach() /home/nsnmt.com/integrity/application/views/data/index.php 505
ERROR - 2022-05-18 05:04:27 --> Severity: Warning --> Invalid argument supplied for foreach() /home/nsnmt.com/integrity/application/views/data/index.php 505
ERROR - 2022-05-18 05:04:27 --> Severity: Warning --> Invalid argument supplied for foreach() /home/nsnmt.com/integrity/application/views/data/index.php 505
ERROR - 2022-05-18 05:04:27 --> Severity: Warning --> Invalid argument supplied for foreach() /home/nsnmt.com/integrity/application/views/data/index.php 505
ERROR - 2022-05-18 05:04:27 --> Severity: Warning --> Invalid argument supplied for foreach() /home/nsnmt.com/integrity/application/views/data/index.php 505
ERROR - 2022-05-18 05:04:27 --> Severity: Warning --> Invalid argument supplied for foreach() /home/nsnmt.com/integrity/application/views/data/index.php 505
ERROR - 2022-05-18 05:04:27 --> Severity: Warning --> Invalid argument supplied for foreach() /home/nsnmt.com/integrity/application/views/data/index.php 505
DEBUG - 2022-05-18 05:04:27 --> Total execution time: 0.0484
DEBUG - 2022-05-18 05:10:09 --> UTF-8 Support Enabled
DEBUG - 2022-05-18 05:10:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-18 05:10:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-05-18 05:10:09 --> Form_validation class already loaded. Second attempt ignored.
ERROR - 2022-05-18 05:10:09 --> Severity: Warning --> Invalid argument supplied for foreach() /home/nsnmt.com/integrity/application/views/data/index.php 507
ERROR - 2022-05-18 05:10:09 --> Severity: Warning --> Invalid argument supplied for foreach() /home/nsnmt.com/integrity/application/views/data/index.php 507
ERROR - 2022-05-18 05:10:09 --> Severity: Warning --> Invalid argument supplied for foreach() /home/nsnmt.com/integrity/application/views/data/index.php 507
ERROR - 2022-05-18 05:10:09 --> Severity: Warning --> Invalid argument supplied for foreach() /home/nsnmt.com/integrity/application/views/data/index.php 507
ERROR - 2022-05-18 05:10:09 --> Severity: Warning --> Invalid argument supplied for foreach() /home/nsnmt.com/integrity/application/views/data/index.php 507
ERROR - 2022-05-18 05:10:09 --> Severity: Warning --> Invalid argument supplied for foreach() /home/nsnmt.com/integrity/application/views/data/index.php 507
ERROR - 2022-05-18 05:10:09 --> Severity: Warning --> Invalid argument supplied for foreach() /home/nsnmt.com/integrity/application/views/data/index.php 507
ERROR - 2022-05-18 05:10:09 --> Severity: Warning --> Invalid argument supplied for foreach() /home/nsnmt.com/integrity/application/views/data/index.php 507
ERROR - 2022-05-18 05:10:09 --> Severity: Warning --> Invalid argument supplied for foreach() /home/nsnmt.com/integrity/application/views/data/index.php 507
ERROR - 2022-05-18 05:10:09 --> Severity: Warning --> Invalid argument supplied for foreach() /home/nsnmt.com/integrity/application/views/data/index.php 507
ERROR - 2022-05-18 05:10:09 --> Severity: Warning --> Invalid argument supplied for foreach() /home/nsnmt.com/integrity/application/views/data/index.php 507
ERROR - 2022-05-18 05:10:09 --> Severity: Warning --> Invalid argument supplied for foreach() /home/nsnmt.com/integrity/application/views/data/index.php 507
DEBUG - 2022-05-18 05:10:09 --> Total execution time: 0.0148
DEBUG - 2022-05-18 05:11:04 --> UTF-8 Support Enabled
DEBUG - 2022-05-18 05:11:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-18 05:11:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-05-18 05:11:04 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-05-18 05:11:30 --> UTF-8 Support Enabled
DEBUG - 2022-05-18 05:11:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-18 05:11:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-05-18 05:11:30 --> Form_validation class already loaded. Second attempt ignored.
ERROR - 2022-05-18 05:11:30 --> Severity: Warning --> Invalid argument supplied for foreach() /home/nsnmt.com/integrity/application/views/data/index.php 506
ERROR - 2022-05-18 05:11:30 --> Severity: Warning --> Invalid argument supplied for foreach() /home/nsnmt.com/integrity/application/views/data/index.php 506
ERROR - 2022-05-18 05:11:30 --> Severity: Warning --> Invalid argument supplied for foreach() /home/nsnmt.com/integrity/application/views/data/index.php 506
ERROR - 2022-05-18 05:11:30 --> Severity: Warning --> Invalid argument supplied for foreach() /home/nsnmt.com/integrity/application/views/data/index.php 506
ERROR - 2022-05-18 05:11:30 --> Severity: Warning --> Invalid argument supplied for foreach() /home/nsnmt.com/integrity/application/views/data/index.php 506
ERROR - 2022-05-18 05:11:30 --> Severity: Warning --> Invalid argument supplied for foreach() /home/nsnmt.com/integrity/application/views/data/index.php 506
ERROR - 2022-05-18 05:11:30 --> Severity: Warning --> Invalid argument supplied for foreach() /home/nsnmt.com/integrity/application/views/data/index.php 506
ERROR - 2022-05-18 05:11:30 --> Severity: Warning --> Invalid argument supplied for foreach() /home/nsnmt.com/integrity/application/views/data/index.php 506
ERROR - 2022-05-18 05:11:30 --> Severity: Warning --> Invalid argument supplied for foreach() /home/nsnmt.com/integrity/application/views/data/index.php 506
ERROR - 2022-05-18 05:11:30 --> Severity: Warning --> Invalid argument supplied for foreach() /home/nsnmt.com/integrity/application/views/data/index.php 506
ERROR - 2022-05-18 05:11:30 --> Severity: Warning --> Invalid argument supplied for foreach() /home/nsnmt.com/integrity/application/views/data/index.php 506
ERROR - 2022-05-18 05:11:30 --> Severity: Warning --> Invalid argument supplied for foreach() /home/nsnmt.com/integrity/application/views/data/index.php 506
DEBUG - 2022-05-18 05:11:30 --> Total execution time: 0.0104
DEBUG - 2022-05-18 05:15:36 --> UTF-8 Support Enabled
DEBUG - 2022-05-18 05:15:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-18 05:15:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-05-18 05:15:36 --> Form_validation class already loaded. Second attempt ignored.
ERROR - 2022-05-18 05:15:36 --> Severity: error --> Exception: Call to undefined function vardump() /home/nsnmt.com/integrity/application/views/data/index.php 506
DEBUG - 2022-05-18 05:17:15 --> UTF-8 Support Enabled
DEBUG - 2022-05-18 05:17:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-18 05:17:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-05-18 05:17:15 --> Form_validation class already loaded. Second attempt ignored.
ERROR - 2022-05-18 05:17:15 --> Severity: Warning --> Invalid argument supplied for foreach() /home/nsnmt.com/integrity/application/views/data/index.php 506
ERROR - 2022-05-18 05:17:15 --> Severity: Warning --> Invalid argument supplied for foreach() /home/nsnmt.com/integrity/application/views/data/index.php 506
ERROR - 2022-05-18 05:17:15 --> Severity: Warning --> Invalid argument supplied for foreach() /home/nsnmt.com/integrity/application/views/data/index.php 506
ERROR - 2022-05-18 05:17:15 --> Severity: Warning --> Invalid argument supplied for foreach() /home/nsnmt.com/integrity/application/views/data/index.php 506
ERROR - 2022-05-18 05:17:15 --> Severity: Warning --> Invalid argument supplied for foreach() /home/nsnmt.com/integrity/application/views/data/index.php 506
ERROR - 2022-05-18 05:17:15 --> Severity: Warning --> Invalid argument supplied for foreach() /home/nsnmt.com/integrity/application/views/data/index.php 506
ERROR - 2022-05-18 05:17:15 --> Severity: Warning --> Invalid argument supplied for foreach() /home/nsnmt.com/integrity/application/views/data/index.php 506
ERROR - 2022-05-18 05:17:15 --> Severity: Warning --> Invalid argument supplied for foreach() /home/nsnmt.com/integrity/application/views/data/index.php 506
ERROR - 2022-05-18 05:17:15 --> Severity: Warning --> Invalid argument supplied for foreach() /home/nsnmt.com/integrity/application/views/data/index.php 506
ERROR - 2022-05-18 05:17:15 --> Severity: Warning --> Invalid argument supplied for foreach() /home/nsnmt.com/integrity/application/views/data/index.php 506
ERROR - 2022-05-18 05:17:15 --> Severity: Warning --> Invalid argument supplied for foreach() /home/nsnmt.com/integrity/application/views/data/index.php 506
ERROR - 2022-05-18 05:17:15 --> Severity: Warning --> Invalid argument supplied for foreach() /home/nsnmt.com/integrity/application/views/data/index.php 506
DEBUG - 2022-05-18 05:17:15 --> Total execution time: 0.0516
DEBUG - 2022-05-18 05:18:51 --> UTF-8 Support Enabled
DEBUG - 2022-05-18 05:18:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-18 05:18:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-05-18 05:18:51 --> Form_validation class already loaded. Second attempt ignored.
ERROR - 2022-05-18 05:18:51 --> Severity: Warning --> Invalid argument supplied for foreach() /home/nsnmt.com/integrity/application/views/data/index.php 506
ERROR - 2022-05-18 05:18:51 --> Severity: Warning --> Invalid argument supplied for foreach() /home/nsnmt.com/integrity/application/views/data/index.php 506
ERROR - 2022-05-18 05:18:51 --> Severity: Warning --> Invalid argument supplied for foreach() /home/nsnmt.com/integrity/application/views/data/index.php 506
ERROR - 2022-05-18 05:18:51 --> Severity: Warning --> Invalid argument supplied for foreach() /home/nsnmt.com/integrity/application/views/data/index.php 506
ERROR - 2022-05-18 05:18:51 --> Severity: Warning --> Invalid argument supplied for foreach() /home/nsnmt.com/integrity/application/views/data/index.php 506
ERROR - 2022-05-18 05:18:51 --> Severity: Warning --> Invalid argument supplied for foreach() /home/nsnmt.com/integrity/application/views/data/index.php 506
ERROR - 2022-05-18 05:18:51 --> Severity: Warning --> Invalid argument supplied for foreach() /home/nsnmt.com/integrity/application/views/data/index.php 506
ERROR - 2022-05-18 05:18:51 --> Severity: Warning --> Invalid argument supplied for foreach() /home/nsnmt.com/integrity/application/views/data/index.php 506
ERROR - 2022-05-18 05:18:51 --> Severity: Warning --> Invalid argument supplied for foreach() /home/nsnmt.com/integrity/application/views/data/index.php 506
ERROR - 2022-05-18 05:18:51 --> Severity: Warning --> Invalid argument supplied for foreach() /home/nsnmt.com/integrity/application/views/data/index.php 506
ERROR - 2022-05-18 05:18:51 --> Severity: Warning --> Invalid argument supplied for foreach() /home/nsnmt.com/integrity/application/views/data/index.php 506
ERROR - 2022-05-18 05:18:51 --> Severity: Warning --> Invalid argument supplied for foreach() /home/nsnmt.com/integrity/application/views/data/index.php 506
DEBUG - 2022-05-18 05:18:51 --> Total execution time: 0.0616
DEBUG - 2022-05-18 05:23:14 --> UTF-8 Support Enabled
DEBUG - 2022-05-18 05:23:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-18 05:23:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-05-18 05:23:14 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-05-18 05:23:14 --> Total execution time: 0.0096
DEBUG - 2022-05-18 05:36:53 --> UTF-8 Support Enabled
DEBUG - 2022-05-18 05:36:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-18 05:36:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-05-18 05:36:53 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-05-18 05:36:53 --> Total execution time: 0.0631
DEBUG - 2022-05-18 05:56:22 --> UTF-8 Support Enabled
DEBUG - 2022-05-18 05:56:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-18 05:56:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-05-18 05:56:22 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-05-18 05:56:22 --> Total execution time: 0.0484
DEBUG - 2022-05-18 06:05:38 --> UTF-8 Support Enabled
DEBUG - 2022-05-18 06:05:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-18 06:05:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-05-18 06:05:38 --> UTF-8 Support Enabled
DEBUG - 2022-05-18 06:05:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-18 06:05:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-05-18 06:05:38 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-05-18 06:05:38 --> Total execution time: 0.0136
DEBUG - 2022-05-18 06:05:41 --> UTF-8 Support Enabled
DEBUG - 2022-05-18 06:05:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-18 06:05:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-05-18 06:05:41 --> Total execution time: 0.0054
DEBUG - 2022-05-18 06:05:47 --> UTF-8 Support Enabled
DEBUG - 2022-05-18 06:05:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-18 06:05:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-05-18 06:05:47 --> UTF-8 Support Enabled
DEBUG - 2022-05-18 06:05:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-18 06:05:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-05-18 06:05:47 --> Total execution time: 0.0034
DEBUG - 2022-05-18 06:05:49 --> UTF-8 Support Enabled
DEBUG - 2022-05-18 06:05:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-18 06:05:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-05-18 06:05:49 --> UTF-8 Support Enabled
DEBUG - 2022-05-18 06:05:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-18 06:05:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-05-18 06:05:49 --> UTF-8 Support Enabled
DEBUG - 2022-05-18 06:05:49 --> Total execution time: 0.0042
DEBUG - 2022-05-18 06:05:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-18 06:05:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-05-18 06:05:49 --> UTF-8 Support Enabled
DEBUG - 2022-05-18 06:05:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-18 06:05:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-05-18 06:05:49 --> Total execution time: 0.0029
DEBUG - 2022-05-18 06:07:01 --> UTF-8 Support Enabled
DEBUG - 2022-05-18 06:07:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-18 06:07:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-05-18 06:07:01 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-05-18 06:07:01 --> Total execution time: 0.0096
DEBUG - 2022-05-18 06:31:42 --> UTF-8 Support Enabled
DEBUG - 2022-05-18 06:31:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-18 06:31:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-05-18 06:31:43 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-05-18 06:31:43 --> Total execution time: 0.0652
DEBUG - 2022-05-18 06:32:21 --> UTF-8 Support Enabled
DEBUG - 2022-05-18 06:32:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-18 06:32:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-05-18 06:32:21 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-05-18 06:32:22 --> Total execution time: 0.0100
DEBUG - 2022-05-18 08:17:59 --> UTF-8 Support Enabled
DEBUG - 2022-05-18 08:17:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-18 08:17:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-05-18 08:17:59 --> UTF-8 Support Enabled
DEBUG - 2022-05-18 08:17:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-18 08:17:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-05-18 08:17:59 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-05-18 08:17:59 --> Total execution time: 0.0166
DEBUG - 2022-05-18 08:18:01 --> UTF-8 Support Enabled
DEBUG - 2022-05-18 08:18:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-18 08:18:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-05-18 08:18:01 --> Total execution time: 0.0055
DEBUG - 2022-05-18 08:18:13 --> UTF-8 Support Enabled
DEBUG - 2022-05-18 08:18:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-18 08:18:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-05-18 08:18:13 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-05-18 08:18:13 --> Total execution time: 0.0048
DEBUG - 2022-05-18 08:18:22 --> UTF-8 Support Enabled
DEBUG - 2022-05-18 08:18:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-18 08:18:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-05-18 08:18:22 --> UTF-8 Support Enabled
DEBUG - 2022-05-18 08:18:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-18 08:18:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-05-18 08:18:22 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-05-18 08:18:22 --> Total execution time: 0.0047
DEBUG - 2022-05-18 08:18:24 --> UTF-8 Support Enabled
DEBUG - 2022-05-18 08:18:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-18 08:18:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-05-18 08:18:24 --> Total execution time: 0.0056
DEBUG - 2022-05-18 08:18:31 --> UTF-8 Support Enabled
DEBUG - 2022-05-18 08:18:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-18 08:18:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-05-18 08:18:31 --> Total execution time: 0.0041
DEBUG - 2022-05-18 08:18:34 --> UTF-8 Support Enabled
DEBUG - 2022-05-18 08:18:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-18 08:18:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-05-18 08:18:34 --> Total execution time: 0.0047
DEBUG - 2022-05-18 08:18:47 --> UTF-8 Support Enabled
DEBUG - 2022-05-18 08:18:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-18 08:18:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-05-18 08:18:47 --> Total execution time: 0.0026
DEBUG - 2022-05-18 16:43:30 --> UTF-8 Support Enabled
DEBUG - 2022-05-18 16:43:30 --> No URI present. Default controller set.
DEBUG - 2022-05-18 16:43:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-18 16:43:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-05-18 16:43:30 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-05-18 16:43:30 --> Total execution time: 0.0481
DEBUG - 2022-05-18 16:43:30 --> UTF-8 Support Enabled
DEBUG - 2022-05-18 16:43:30 --> No URI present. Default controller set.
DEBUG - 2022-05-18 16:43:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-18 16:43:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-05-18 16:43:30 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-05-18 16:43:30 --> Total execution time: 0.0023
DEBUG - 2022-05-18 19:10:31 --> UTF-8 Support Enabled
DEBUG - 2022-05-18 19:10:31 --> No URI present. Default controller set.
DEBUG - 2022-05-18 19:10:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-18 19:10:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-05-18 19:10:31 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-05-18 19:10:31 --> Total execution time: 0.0368
DEBUG - 2022-05-18 19:10:33 --> UTF-8 Support Enabled
DEBUG - 2022-05-18 19:10:33 --> No URI present. Default controller set.
DEBUG - 2022-05-18 19:10:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-18 19:10:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-05-18 19:10:33 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-05-18 19:10:33 --> Total execution time: 0.0017
