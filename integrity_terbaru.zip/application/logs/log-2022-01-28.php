<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

DEBUG - 2022-01-28 00:07:12 --> UTF-8 Support Enabled
DEBUG - 2022-01-28 00:07:12 --> No URI present. Default controller set.
DEBUG - 2022-01-28 00:07:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-28 00:07:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-28 00:07:12 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-28 00:07:12 --> Total execution time: 0.0314
DEBUG - 2022-01-28 09:33:51 --> UTF-8 Support Enabled
DEBUG - 2022-01-28 09:33:51 --> No URI present. Default controller set.
DEBUG - 2022-01-28 09:33:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-28 09:33:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-28 09:33:51 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-28 09:33:51 --> Total execution time: 0.0305
DEBUG - 2022-01-28 09:33:51 --> UTF-8 Support Enabled
DEBUG - 2022-01-28 09:33:51 --> No URI present. Default controller set.
DEBUG - 2022-01-28 09:33:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-28 09:33:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-28 09:33:51 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-28 09:33:51 --> Total execution time: 0.0034
DEBUG - 2022-01-28 09:33:51 --> UTF-8 Support Enabled
DEBUG - 2022-01-28 09:33:51 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-01-28 09:33:51 --> 404 Page Not Found: Assets/https:
DEBUG - 2022-01-28 09:36:55 --> UTF-8 Support Enabled
DEBUG - 2022-01-28 09:36:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-28 09:36:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-28 09:36:55 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-28 09:36:55 --> UTF-8 Support Enabled
DEBUG - 2022-01-28 09:36:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-28 09:36:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-28 09:36:55 --> Total execution time: 0.0066
DEBUG - 2022-01-28 09:36:57 --> UTF-8 Support Enabled
DEBUG - 2022-01-28 09:36:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-28 09:36:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-28 09:36:57 --> Form_validation class already loaded. Second attempt ignored.
ERROR - 2022-01-28 09:36:57 --> Severity: Error --> Allowed memory size of 268435456 bytes exhausted (tried to allocate 134294448 bytes) /home/dunr4521/public_html/integrity/system/core/Loader.php 996
DEBUG - 2022-01-28 09:38:12 --> UTF-8 Support Enabled
DEBUG - 2022-01-28 09:38:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-28 09:38:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-28 09:38:12 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-28 09:38:12 --> Total execution time: 0.0329
DEBUG - 2022-01-28 09:57:56 --> UTF-8 Support Enabled
DEBUG - 2022-01-28 09:57:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-28 09:57:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-28 09:57:56 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-28 09:57:56 --> UTF-8 Support Enabled
DEBUG - 2022-01-28 09:57:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-28 09:57:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-28 09:57:56 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-28 09:57:56 --> Total execution time: 0.0066
DEBUG - 2022-01-28 10:05:17 --> UTF-8 Support Enabled
DEBUG - 2022-01-28 10:05:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-28 10:05:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-28 10:05:17 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-28 10:05:17 --> UTF-8 Support Enabled
DEBUG - 2022-01-28 10:05:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-28 10:05:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-28 10:05:17 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-28 10:05:17 --> Total execution time: 0.0058
DEBUG - 2022-01-28 10:16:54 --> UTF-8 Support Enabled
DEBUG - 2022-01-28 10:16:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-28 10:16:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-28 10:16:54 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-28 10:16:54 --> UTF-8 Support Enabled
DEBUG - 2022-01-28 10:16:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-28 10:16:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-28 10:16:54 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-28 10:16:54 --> Total execution time: 0.0064
DEBUG - 2022-01-28 10:27:47 --> UTF-8 Support Enabled
DEBUG - 2022-01-28 10:27:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-28 10:27:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-28 10:27:47 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-28 10:27:47 --> UTF-8 Support Enabled
DEBUG - 2022-01-28 10:27:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-28 10:27:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-28 10:27:47 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-28 10:27:47 --> Total execution time: 0.0058
DEBUG - 2022-01-28 10:31:36 --> UTF-8 Support Enabled
DEBUG - 2022-01-28 10:31:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-28 10:31:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-28 10:31:36 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-28 10:31:36 --> UTF-8 Support Enabled
DEBUG - 2022-01-28 10:31:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-28 10:31:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-28 10:31:36 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-28 10:31:36 --> Total execution time: 0.0058
DEBUG - 2022-01-28 10:34:39 --> UTF-8 Support Enabled
DEBUG - 2022-01-28 10:34:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-28 10:34:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-28 10:34:39 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-28 10:34:39 --> UTF-8 Support Enabled
DEBUG - 2022-01-28 10:34:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-28 10:34:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-28 10:34:39 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-28 10:34:39 --> Total execution time: 0.0061
DEBUG - 2022-01-28 10:41:38 --> UTF-8 Support Enabled
DEBUG - 2022-01-28 10:41:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-28 10:41:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-28 10:41:38 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-28 10:41:38 --> UTF-8 Support Enabled
DEBUG - 2022-01-28 10:41:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-28 10:41:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-28 10:41:38 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-28 10:41:38 --> Total execution time: 0.0061
DEBUG - 2022-01-28 10:45:18 --> UTF-8 Support Enabled
DEBUG - 2022-01-28 10:45:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-28 10:45:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-28 10:45:18 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-28 10:45:18 --> UTF-8 Support Enabled
DEBUG - 2022-01-28 10:45:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-28 10:45:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-28 10:45:18 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-28 10:45:18 --> Total execution time: 0.0062
DEBUG - 2022-01-28 10:47:28 --> UTF-8 Support Enabled
DEBUG - 2022-01-28 10:47:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-28 10:47:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-28 10:47:28 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-28 10:47:28 --> UTF-8 Support Enabled
DEBUG - 2022-01-28 10:47:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-28 10:47:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-28 10:47:28 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-28 10:47:28 --> Total execution time: 0.0051
DEBUG - 2022-01-28 10:51:35 --> UTF-8 Support Enabled
DEBUG - 2022-01-28 10:51:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-28 10:51:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-28 10:51:35 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-28 10:51:35 --> UTF-8 Support Enabled
DEBUG - 2022-01-28 10:51:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-28 10:51:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-28 10:51:35 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-28 10:51:35 --> Total execution time: 0.0074
DEBUG - 2022-01-28 10:57:25 --> UTF-8 Support Enabled
DEBUG - 2022-01-28 10:57:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-28 10:57:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-28 10:57:25 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-28 10:57:25 --> UTF-8 Support Enabled
DEBUG - 2022-01-28 10:57:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-28 10:57:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-28 10:57:25 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-28 10:57:25 --> Total execution time: 0.0075
DEBUG - 2022-01-28 11:04:31 --> UTF-8 Support Enabled
DEBUG - 2022-01-28 11:04:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-28 11:04:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-28 11:04:31 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-28 11:04:31 --> UTF-8 Support Enabled
DEBUG - 2022-01-28 11:04:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-28 11:04:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-28 11:04:31 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-28 11:04:31 --> Total execution time: 0.0060
DEBUG - 2022-01-28 11:13:31 --> UTF-8 Support Enabled
DEBUG - 2022-01-28 11:13:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-28 11:13:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-28 11:13:32 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-28 11:13:32 --> UTF-8 Support Enabled
DEBUG - 2022-01-28 11:13:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-28 11:13:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-28 11:13:32 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-28 11:13:32 --> Total execution time: 0.0069
DEBUG - 2022-01-28 11:19:29 --> UTF-8 Support Enabled
DEBUG - 2022-01-28 11:19:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-28 11:19:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-28 11:19:29 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-28 11:19:29 --> UTF-8 Support Enabled
DEBUG - 2022-01-28 11:19:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-28 11:19:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-28 11:19:29 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-28 11:19:29 --> Total execution time: 0.0059
DEBUG - 2022-01-28 11:23:41 --> UTF-8 Support Enabled
DEBUG - 2022-01-28 11:23:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-28 11:23:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-28 11:23:41 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-28 11:23:41 --> UTF-8 Support Enabled
DEBUG - 2022-01-28 11:23:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-28 11:23:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-28 11:23:41 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-28 11:23:41 --> Total execution time: 0.0063
DEBUG - 2022-01-28 11:28:24 --> UTF-8 Support Enabled
DEBUG - 2022-01-28 11:28:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-28 11:28:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-28 11:28:24 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-28 11:28:24 --> UTF-8 Support Enabled
DEBUG - 2022-01-28 11:28:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-28 11:28:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-28 11:28:24 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-28 11:28:24 --> Total execution time: 0.0061
DEBUG - 2022-01-28 11:38:17 --> UTF-8 Support Enabled
DEBUG - 2022-01-28 11:38:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-28 11:38:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-28 11:38:17 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-28 11:38:17 --> UTF-8 Support Enabled
DEBUG - 2022-01-28 11:38:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-28 11:38:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-28 11:38:17 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-28 11:38:17 --> Total execution time: 0.0061
DEBUG - 2022-01-28 11:43:06 --> UTF-8 Support Enabled
DEBUG - 2022-01-28 11:43:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-28 11:43:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-28 11:43:06 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-28 11:43:06 --> UTF-8 Support Enabled
DEBUG - 2022-01-28 11:43:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-28 11:43:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-28 11:43:06 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-28 11:43:06 --> Total execution time: 0.0069
DEBUG - 2022-01-28 13:39:04 --> UTF-8 Support Enabled
DEBUG - 2022-01-28 13:39:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-28 13:39:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-28 13:39:04 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-28 13:39:04 --> UTF-8 Support Enabled
DEBUG - 2022-01-28 13:39:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-28 13:39:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-28 13:39:04 --> Form_validation class already loaded. Second attempt ignored.
ERROR - 2022-01-28 13:39:04 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near 'ORDER BY `user_access_menu`.`menu_id` ASC' at line 5 - Invalid query: SELECT `user_menu`.`id`,`menu` 
                    FROM `user_menu` JOIN `user_access_menu` 
                    ON `user_menu`.`id` = `user_access_menu`.`menu_id` 
                    WHERE `user_access_menu`.`role_id` = 
                    ORDER BY `user_access_menu`.`menu_id` ASC
                    
ERROR - 2022-01-28 13:39:04 --> Severity: error --> Exception: Call to a member function result_array() on bool /home/dunr4521/public_html/integrity/application/views/templates/sidebar.php 23
DEBUG - 2022-01-28 13:39:49 --> UTF-8 Support Enabled
DEBUG - 2022-01-28 13:39:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-28 13:39:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-28 13:39:49 --> Form_validation class already loaded. Second attempt ignored.
ERROR - 2022-01-28 13:39:49 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near 'ORDER BY `user_access_menu`.`menu_id` ASC' at line 5 - Invalid query: SELECT `user_menu`.`id`,`menu` 
                    FROM `user_menu` JOIN `user_access_menu` 
                    ON `user_menu`.`id` = `user_access_menu`.`menu_id` 
                    WHERE `user_access_menu`.`role_id` = 
                    ORDER BY `user_access_menu`.`menu_id` ASC
                    
ERROR - 2022-01-28 13:39:49 --> Severity: error --> Exception: Call to a member function result_array() on bool /home/dunr4521/public_html/integrity/application/views/templates/sidebar.php 23
DEBUG - 2022-01-28 13:39:51 --> UTF-8 Support Enabled
DEBUG - 2022-01-28 13:39:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-28 13:39:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-28 13:39:51 --> Form_validation class already loaded. Second attempt ignored.
ERROR - 2022-01-28 13:39:51 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near 'ORDER BY `user_access_menu`.`menu_id` ASC' at line 5 - Invalid query: SELECT `user_menu`.`id`,`menu` 
                    FROM `user_menu` JOIN `user_access_menu` 
                    ON `user_menu`.`id` = `user_access_menu`.`menu_id` 
                    WHERE `user_access_menu`.`role_id` = 
                    ORDER BY `user_access_menu`.`menu_id` ASC
                    
ERROR - 2022-01-28 13:39:51 --> Severity: error --> Exception: Call to a member function result_array() on bool /home/dunr4521/public_html/integrity/application/views/templates/sidebar.php 23
DEBUG - 2022-01-28 13:39:52 --> UTF-8 Support Enabled
DEBUG - 2022-01-28 13:39:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-28 13:39:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-28 13:39:52 --> Form_validation class already loaded. Second attempt ignored.
ERROR - 2022-01-28 13:39:52 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near 'ORDER BY `user_access_menu`.`menu_id` ASC' at line 5 - Invalid query: SELECT `user_menu`.`id`,`menu` 
                    FROM `user_menu` JOIN `user_access_menu` 
                    ON `user_menu`.`id` = `user_access_menu`.`menu_id` 
                    WHERE `user_access_menu`.`role_id` = 
                    ORDER BY `user_access_menu`.`menu_id` ASC
                    
ERROR - 2022-01-28 13:39:52 --> Severity: error --> Exception: Call to a member function result_array() on bool /home/dunr4521/public_html/integrity/application/views/templates/sidebar.php 23
DEBUG - 2022-01-28 13:40:10 --> UTF-8 Support Enabled
DEBUG - 2022-01-28 13:40:10 --> No URI present. Default controller set.
DEBUG - 2022-01-28 13:40:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-28 13:40:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-28 13:40:10 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-28 13:40:10 --> Total execution time: 0.0052
DEBUG - 2022-01-28 13:40:10 --> UTF-8 Support Enabled
DEBUG - 2022-01-28 13:40:10 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-01-28 13:40:10 --> 404 Page Not Found: Assets/https:
DEBUG - 2022-01-28 13:40:11 --> UTF-8 Support Enabled
DEBUG - 2022-01-28 13:40:11 --> No URI present. Default controller set.
DEBUG - 2022-01-28 13:40:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-28 13:40:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-28 13:40:11 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-28 13:40:11 --> Total execution time: 0.0031
DEBUG - 2022-01-28 13:40:22 --> UTF-8 Support Enabled
DEBUG - 2022-01-28 13:40:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-28 13:40:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-28 13:40:22 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-28 13:40:22 --> UTF-8 Support Enabled
DEBUG - 2022-01-28 13:40:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-28 13:40:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-28 13:40:22 --> Total execution time: 0.0060
DEBUG - 2022-01-28 13:40:24 --> UTF-8 Support Enabled
DEBUG - 2022-01-28 13:40:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-28 13:40:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-28 13:40:24 --> Form_validation class already loaded. Second attempt ignored.
ERROR - 2022-01-28 13:40:24 --> Severity: Error --> Allowed memory size of 268435456 bytes exhausted (tried to allocate 136604288 bytes) /home/dunr4521/public_html/integrity/system/core/Loader.php 996
DEBUG - 2022-01-28 13:40:27 --> UTF-8 Support Enabled
DEBUG - 2022-01-28 13:40:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-28 13:40:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-28 13:40:27 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-28 13:40:27 --> Total execution time: 0.0040
DEBUG - 2022-01-28 13:52:52 --> UTF-8 Support Enabled
DEBUG - 2022-01-28 13:52:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-28 13:52:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-28 13:52:52 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-28 13:52:52 --> UTF-8 Support Enabled
DEBUG - 2022-01-28 13:52:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-28 13:52:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-28 13:52:52 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-28 13:52:52 --> Total execution time: 0.0063
DEBUG - 2022-01-28 13:56:54 --> UTF-8 Support Enabled
DEBUG - 2022-01-28 13:56:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-28 13:56:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-28 13:56:54 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-28 13:56:54 --> UTF-8 Support Enabled
DEBUG - 2022-01-28 13:56:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-28 13:56:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-28 13:56:54 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-28 13:56:54 --> Total execution time: 0.0063
DEBUG - 2022-01-28 14:07:14 --> UTF-8 Support Enabled
DEBUG - 2022-01-28 14:07:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-28 14:07:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-28 14:07:14 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-28 14:07:14 --> UTF-8 Support Enabled
DEBUG - 2022-01-28 14:07:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-28 14:07:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-28 14:07:14 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-28 14:07:14 --> Total execution time: 0.0056
DEBUG - 2022-01-28 14:10:06 --> UTF-8 Support Enabled
DEBUG - 2022-01-28 14:10:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-28 14:10:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-28 14:10:06 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-28 14:10:06 --> UTF-8 Support Enabled
DEBUG - 2022-01-28 14:10:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-28 14:10:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-28 14:10:06 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-28 14:10:06 --> Total execution time: 0.0052
DEBUG - 2022-01-28 14:18:51 --> UTF-8 Support Enabled
DEBUG - 2022-01-28 14:18:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-28 14:18:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-28 14:18:51 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-28 14:18:51 --> UTF-8 Support Enabled
DEBUG - 2022-01-28 14:18:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-28 14:18:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-28 14:18:51 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-28 14:18:51 --> Total execution time: 0.0060
DEBUG - 2022-01-28 14:22:48 --> UTF-8 Support Enabled
DEBUG - 2022-01-28 14:22:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-28 14:22:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-28 14:22:48 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-28 14:22:48 --> UTF-8 Support Enabled
DEBUG - 2022-01-28 14:22:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-28 14:22:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-28 14:22:48 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-28 14:22:48 --> Total execution time: 0.0058
DEBUG - 2022-01-28 14:28:14 --> UTF-8 Support Enabled
DEBUG - 2022-01-28 14:28:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-28 14:28:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-28 14:28:14 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-28 14:28:14 --> UTF-8 Support Enabled
DEBUG - 2022-01-28 14:28:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-28 14:28:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-28 14:28:14 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-28 14:28:14 --> Total execution time: 0.0063
DEBUG - 2022-01-28 14:34:41 --> UTF-8 Support Enabled
DEBUG - 2022-01-28 14:34:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-28 14:34:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-28 14:34:41 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-28 14:34:41 --> UTF-8 Support Enabled
DEBUG - 2022-01-28 14:34:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-28 14:34:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-28 14:34:41 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-28 14:34:41 --> Total execution time: 0.0057
DEBUG - 2022-01-28 14:45:02 --> UTF-8 Support Enabled
DEBUG - 2022-01-28 14:45:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-28 14:45:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-28 14:45:02 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-28 14:45:02 --> UTF-8 Support Enabled
DEBUG - 2022-01-28 14:45:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-28 14:45:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-28 14:45:02 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-28 14:45:02 --> Total execution time: 0.0065
DEBUG - 2022-01-28 14:49:04 --> UTF-8 Support Enabled
DEBUG - 2022-01-28 14:49:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-28 14:49:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-28 14:49:04 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-28 14:49:04 --> UTF-8 Support Enabled
DEBUG - 2022-01-28 14:49:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-28 14:49:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-28 14:49:04 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-28 14:49:04 --> Total execution time: 0.0062
DEBUG - 2022-01-28 14:51:37 --> UTF-8 Support Enabled
DEBUG - 2022-01-28 14:51:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-28 14:51:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-28 14:51:37 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-28 14:51:37 --> UTF-8 Support Enabled
DEBUG - 2022-01-28 14:51:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-28 14:51:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-28 14:51:37 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-28 14:51:37 --> Total execution time: 0.0060
DEBUG - 2022-01-28 14:54:53 --> UTF-8 Support Enabled
DEBUG - 2022-01-28 14:54:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-28 14:54:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-28 14:54:53 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-28 14:54:53 --> UTF-8 Support Enabled
DEBUG - 2022-01-28 14:54:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-28 14:54:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-28 14:54:53 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-28 14:54:53 --> Total execution time: 0.0060
DEBUG - 2022-01-28 14:57:49 --> UTF-8 Support Enabled
DEBUG - 2022-01-28 14:57:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-28 14:57:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-28 14:57:49 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-28 14:57:49 --> UTF-8 Support Enabled
DEBUG - 2022-01-28 14:57:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-28 14:57:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-28 14:57:49 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-28 14:57:49 --> Total execution time: 0.0059
DEBUG - 2022-01-28 15:27:44 --> UTF-8 Support Enabled
DEBUG - 2022-01-28 15:27:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-28 15:27:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-28 15:27:44 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-28 15:27:44 --> UTF-8 Support Enabled
DEBUG - 2022-01-28 15:27:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-28 15:27:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-28 15:27:44 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-28 15:27:44 --> Total execution time: 0.0067
DEBUG - 2022-01-28 15:34:14 --> UTF-8 Support Enabled
DEBUG - 2022-01-28 15:34:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-28 15:34:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-28 15:34:14 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-28 15:34:14 --> UTF-8 Support Enabled
DEBUG - 2022-01-28 15:34:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-28 15:34:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-28 15:34:14 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-28 15:34:14 --> Total execution time: 0.0054
DEBUG - 2022-01-28 16:18:31 --> UTF-8 Support Enabled
DEBUG - 2022-01-28 16:18:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-28 16:18:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-28 16:18:31 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-28 16:18:31 --> UTF-8 Support Enabled
DEBUG - 2022-01-28 16:18:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-28 16:18:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-28 16:18:31 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-28 16:18:31 --> Total execution time: 0.0072
DEBUG - 2022-01-28 16:22:26 --> UTF-8 Support Enabled
DEBUG - 2022-01-28 16:22:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-28 16:22:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-28 16:22:26 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-28 16:22:27 --> UTF-8 Support Enabled
DEBUG - 2022-01-28 16:22:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-28 16:22:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-28 16:22:27 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-28 16:22:27 --> Total execution time: 0.0069
DEBUG - 2022-01-28 16:24:40 --> UTF-8 Support Enabled
DEBUG - 2022-01-28 16:24:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-28 16:24:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-28 16:24:40 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-28 16:24:40 --> UTF-8 Support Enabled
DEBUG - 2022-01-28 16:24:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-28 16:24:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-28 16:24:40 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-28 16:24:40 --> Total execution time: 0.0051
DEBUG - 2022-01-28 16:28:34 --> UTF-8 Support Enabled
DEBUG - 2022-01-28 16:28:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-28 16:28:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-28 16:28:34 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-28 16:28:34 --> UTF-8 Support Enabled
DEBUG - 2022-01-28 16:28:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-28 16:28:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-28 16:28:34 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-28 16:28:34 --> Total execution time: 0.0050
DEBUG - 2022-01-28 16:30:57 --> UTF-8 Support Enabled
DEBUG - 2022-01-28 16:30:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-28 16:30:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-28 16:30:57 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-28 16:30:57 --> UTF-8 Support Enabled
DEBUG - 2022-01-28 16:30:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-28 16:30:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-28 16:30:57 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-28 16:30:57 --> Total execution time: 0.0046
DEBUG - 2022-01-28 16:34:19 --> UTF-8 Support Enabled
DEBUG - 2022-01-28 16:34:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-28 16:34:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-28 16:34:19 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-28 16:34:19 --> UTF-8 Support Enabled
DEBUG - 2022-01-28 16:34:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-28 16:34:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-28 16:34:19 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-28 16:34:19 --> Total execution time: 0.0054
DEBUG - 2022-01-28 16:36:58 --> UTF-8 Support Enabled
DEBUG - 2022-01-28 16:36:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-28 16:36:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-28 16:36:58 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-28 16:36:58 --> UTF-8 Support Enabled
DEBUG - 2022-01-28 16:36:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-28 16:36:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-28 16:36:58 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-28 16:36:58 --> Total execution time: 0.0063
DEBUG - 2022-01-28 16:46:47 --> UTF-8 Support Enabled
DEBUG - 2022-01-28 16:46:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-28 16:46:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-28 16:46:47 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-28 16:46:47 --> UTF-8 Support Enabled
DEBUG - 2022-01-28 16:46:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-28 16:46:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-28 16:46:47 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-28 16:46:47 --> Total execution time: 0.0063
DEBUG - 2022-01-28 16:51:18 --> UTF-8 Support Enabled
DEBUG - 2022-01-28 16:51:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-28 16:51:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-28 16:51:18 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-28 16:51:18 --> UTF-8 Support Enabled
DEBUG - 2022-01-28 16:51:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-28 16:51:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-28 16:51:18 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-28 16:51:18 --> Total execution time: 0.0063
DEBUG - 2022-01-28 16:54:35 --> UTF-8 Support Enabled
DEBUG - 2022-01-28 16:54:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-28 16:54:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-28 16:54:35 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-28 16:54:36 --> UTF-8 Support Enabled
DEBUG - 2022-01-28 16:54:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-28 16:54:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-28 16:54:36 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-28 16:54:36 --> Total execution time: 0.0046
DEBUG - 2022-01-28 16:58:15 --> UTF-8 Support Enabled
DEBUG - 2022-01-28 16:58:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-28 16:58:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-28 16:58:15 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-28 16:58:15 --> UTF-8 Support Enabled
DEBUG - 2022-01-28 16:58:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-28 16:58:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-28 16:58:15 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-28 16:58:15 --> Total execution time: 0.0048
